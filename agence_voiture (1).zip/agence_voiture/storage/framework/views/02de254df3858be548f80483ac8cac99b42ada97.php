
<!DOCTYPE html>


<!--[if IE 7 ]><html lang="fr-MA"  class="no-js ie7 lt-ie8 lt-ie9 lt-ie10 ltr"><![endif]-->
<!--[if IE 8 ]><html lang="fr-MA"  class="no-js ie8 lt-ie9 lt-ie10 ltr"><![endif]-->
<!--[if IE 9 ]><html lang="fr-MA"  class="no-js ie9 lt-ie10 ltr"><![endif]-->
<!--[if IEMobile 7 ]><html lang="fr-MA"  class="no-js iem7 ltr"><![endif]-->
<!--[if (gt IE 9)|!(IE)|(gt IEMobile 7)|!(IEMobile) ]><!--><html lang="fr-MA"  class="no-js"><!--<![endif]-->


 <html lang="fr-MA"  class="no-js">


<head>
    <?php echo $__env->yieldContent('head'); ?>
    

</head>

<body class="branch-location content-page">
    <header>     <?php echo $__env->yieldContent('header'); ?>   </header>
    <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                </div>
        <?php echo $__env->yieldContent('content'); ?>

       <?php echo $__env->yieldContent('footer'); ?>  



</body>

</html>