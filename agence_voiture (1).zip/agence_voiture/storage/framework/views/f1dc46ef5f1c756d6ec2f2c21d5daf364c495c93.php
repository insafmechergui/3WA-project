<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('inc.head',['title'=>'accueil'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
            <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">

<h2><?php echo e($voiture->model); ?></h2>
<span><?php echo e($voiture->prix); ?> DT</span>


<div class="info-box" >
      <form action="<?php echo e(route('handleReservation')); ?>" method="post">
        <input type="hidden" name="id" value="<?php echo e($voiture->id); ?>">
        
        <label for="date">Date de réservation</label>
        <input type="date" class="form-control" name="date_locat">
        <input type="time" class="form-control" name="time_locat">

         <label for="date">Date de retour</label>
        <input type="date" class="form-control" name="date_ret">
        <input type="time" class="form-control" name="time_ret">

        <input type="submit" class="btn" value="Reserver">
        <?php echo e(csrf_field()); ?>

      </form>
</div>
</div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('footer'); ?>
      <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>