

<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('inc.head',['title'=>'Ajouter une voiture'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
            <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container">
<form class="form" method="POST" action="<?php echo e(route('handlecontent')); ?>" enctype="multipart/form-data">
    
    <div class="form-row">
      <label for="model">model</label>
      <input type="text" name="model"/>
    </div>
    <div class="form-row">
      <label for="marque">marque</label>
      <input type="text" name="marque"/>
    </div>
    <div class="form-row">
      <label for="porte">puissance</label>
      <input type="text" name="puissance"/>
    </div>
    <div class="form-row">
      <label for="type">type</label>
      <select name="type" class="form-control" >
              <?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($types->id); ?>"><?php echo e($types->type); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

      </select> 
    </div>

    <div class="form-row">
      <label for="etat">etat</label>
      <select name="etat" class="form-control" >
              <?php $__currentLoopData = $etats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($etat->id); ?>"><?php echo e($etat->etat); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

      </select> 
    </div>
    <div class="form-row">
      <label for="prix">prix</label>
      <input type="text" name="prix" />
    </div>
    <div class="form-row">
      <label for="coleur">coleur</label>
      <input type="text" name="coleur" />
    </div>
    <div class="form-row">
      <label for="place">nb de place</label>
      <input type="number" name="place"/>
    </div>
    <div class="form-row">
      <label for="porte">nb de porte</label>
      <input type="number" name="porte"/>
    </div>
    <div  class="form-control" >
      <label for="photo">photo</label>
      <input type="file" name="photo[]" multiple />
    </div>
    

    <div class="form-row">
      <button class="submit-button" type="submit" >
        Ajouter une voiture 
      </button>
      
    </div>
    <?php echo e(csrf_field()); ?>

  </form>
</div>
<?php $__env->stopSection(); ?>

        <?php $__env->startSection('footer'); ?>
            <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>