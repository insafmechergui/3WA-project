<?php

echo trans('User::example.welcome');