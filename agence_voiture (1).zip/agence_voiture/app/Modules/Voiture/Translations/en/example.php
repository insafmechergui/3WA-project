<?php 

return [
    'welcome' => 'Welcome, this is Voiture module.'
];
