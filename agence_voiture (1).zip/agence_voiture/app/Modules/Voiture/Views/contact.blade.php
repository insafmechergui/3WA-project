

@extends('layout')

@section('head')
    @include('inc.head',['title'=>'accueil'])
@endsection
@section('header')
            @include('inc.header')

        @endsection
@section('content')
<table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top" bgcolor="#000000"><table width="741" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td valign="top">
		<form action="" method="post" name="form1" id="form1" style="margin-bottom:auto;">
		<table width="741" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td width="12" valign="top">&nbsp;</td>
              <td colspan="3" valign="top">&nbsp;</td>
              <td width="12" valign="top">&nbsp;</td>
            </tr>
            <tr>
              <td width="12" valign="top"><img src="images/index_06.gif" width="12" height="69" alt="" /></td>
              <td width="443" valign="top" style="background-image:url(images/index_08.gif);"><div style="padding-left:20px; padding-top:23px;"><a href="index.html"><img src="images/index_12.gif" alt="" width="189" height="24" border="0" /></a></div></td>
              <td width="203" align="right" valign="middle" style="background-image:url(images/index_08.gif);"><input name="textfield" type="text" style="height:20px;" value=" -- Site Search --" /></td>
              <td width="71" align="right" valign="middle" style="background-image:url(images/index_08.gif);"><input type="image" name="imageField" src="images/index_15.gif" style="border:0px;" /></td>
              <td width="12" valign="top"><img src="images/index_10.gif" width="12" height="69" alt="" /></td>
            </tr>
            <tr>
              <td height="15px" colspan="5" valign="top"></td>
            </tr>
            <tr>
              <td colspan="5" valign="top"><table width="741" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="291" valign="top"><img src="images/index_22.gif" width="291" height="224" alt="" /></td>
                  <td width="247" valign="top"><img src="images/index_23.gif" width="247" height="224" alt="" /></td>
                  <td width="12" valign="top"><img src="images/index_24.gif" width="12" height="224" alt="" /></td>
                  <td width="158" valign="top" style="background-image:url(images/index_26.gif);" class="menu"><a href="index.html">HOME</a> <br />
                                <a href="content.html">ABOUT US</a> <br />
                                <a href="content.html">NEW CARS</a><br />
                                <a href="content.html">DEALERS </a><br />
                                <a href="content.html">SERVICES </a><br />
                            <a href="contact.html">CONTACT US</a></td>
                  <td width="33" valign="top"><img src="images/index_28.gif" width="33" height="224" alt="" /></td>
                </tr>
              </table>
			  
			  </td>
            </tr>
            <tr>
              <td height="8px" colspan="5" valign="top"></td>
            </tr>
          
        </table>
		</form>
		</td>
      </tr>
      <tr>
        <td valign="top"><table width="741" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="135" height="80" align="center" bgcolor="#FFFFFF" class="border1"><a href="#"><img src="images/index_39.gif" alt="" width="113" height="49" border="0" /></a></td>
            <td width="152" height="80" align="center" bgcolor="#FFFFFF" class="border1"><a href="#"><img src="images/index_41.gif" alt="" width="120" height="50" border="0" /></a></td>
            <td width="153" height="80" align="center" bgcolor="#FFFFFF" class="border1"><a href="#"><img src="images/index_33.gif" alt="" width="105" height="50" border="0" /></a></td>
            <td width="151" height="80" align="center" bgcolor="#FFFFFF" class="border1"><a href="#"><img src="images/index_44.gif" alt="" width="123" height="39" border="0" /></a></td>
            <td width="150" height="80" align="center" bgcolor="#FFFFFF"><a href="#"><img src="images/index_36.gif" alt="" width="122" height="50" border="0" /></a></td>
          </tr>
          <tr>
            <td height="10px" colspan="5" valign="top"></td>
          </tr>
          <tr>
            <td colspan="5" valign="top" style="padding-bottom:12px;"><table width="741" border="0" cellspacing="6" cellpadding="0">
              <tr>
                <td width="245" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td class="border"><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td height="30" colspan="2"><img src="images/index_57.gif" width="132" height="16" alt="" /></td>
                      </tr>
                      <tr>
                        <td height="10" colspan="2" valign="top"><span class="style1">----------------------------------</span></td>
                      </tr>
                      <tr>
                        <td colspan="2"></td>
                      </tr>
                      <tr>
                        <td height="25" colspan="2" valign="top" class="text">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. NulLorem.g elit.</td>
                      </tr>
                      <tr>
                        <td colspan="2" valign="top"><span class="style1">----------------------------------</span></td>
                      </tr>
                      <tr>
                        <td width="14%" align="center" valign="middle"><img src="images/index_63.gif" width="10" height="11" alt="" /></td>
                        <td width="86%" valign="top" class="text"><a href="#"><strong>MORE INFO</strong></a><strong> </strong></td>
                      </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td height="10px"></td>
                  </tr>
                  <tr>
                    <td bgcolor="313131" class="border"><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="313131">
                      <tr>
                        <td height="30" colspan="2"><img src="images/index_67.gif" width="101" height="16" alt="" /></td>
                      </tr>
                      <tr>
                        <td height="10" colspan="2" valign="top"><span class="style1">----------------------------------</span></td>
                      </tr>
                      <tr>
                        <td colspan="2"></td>
                      </tr>
                      <tr>
                        <td height="25" colspan="2" valign="top" class="text">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. NulLorem.g elit.</td>
                      </tr>
                      <tr>
                        <td width="14%" align="center" valign="middle"><img src="images/index_63.gif" width="10" height="11" alt="" /></td>
                        <td width="86%" valign="top" class="text"><a href="#"><strong>MORE INFO</strong></a><strong> </strong></td>
                      </tr>
                    </table></td>
                  </tr>
                </table></td>
                <td valign="top" class="body"><form id="form2" name="form2" method="post" action="">
                  <table width="93%" border="0" align="center" cellpadding="2" cellspacing="4" class="border">
                    <tr>
                      <td height="35" colspan="3" valign="top" class="heading" style="padding-top:8px; color:#0066FF;"><span class="style5">Contact Us :</span></td>
                    </tr>
                    <tr>
                      <td width="36%" class="body1">Your Name:</td>
                      <td width="64%" colspan="2"><input type="text" name="textfield3" style="width:250px; height:13px;" /></td>
                    </tr>
                    <tr>
                      <td class="body">Address:</td>
                      <td colspan="2"><input type="text" name="textfield32" style="width:250px; height:13px;" /></td>
                    </tr>
                    <tr>
                      <td class="body">City:</td>
                      <td colspan="2"><input type="text" name="textfield33" style="width:250px; height:13px;" /></td>
                    </tr>
                    <tr>
                      <td class="body"> Country:</td>
                      <td colspan="2"><input type="text" name="textfield34" style="width:250px; height:13px;" /></td>
                    </tr>
                    <tr>
                      <td class="body">Phone no:</td>
                      <td colspan="2"><input type="text" name="textfield35" style="width:250px; height:13px;" /></td>
                    </tr>
                    <tr>
                      <td class="body">email Address:</td>
                      <td colspan="2"><input type="text" name="textfield36" style="width:250px; height:13px;" /></td>
                    </tr>
                    <tr>
                      <td class="body">Comments:</td>
                      <td colspan="2"><textarea name="textarea" rows="5" cols="" style="width:250px;"></textarea></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td colspan="2"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="28%"><input type="image" name="imageField2" src="images/submit.gif" /></td>
                            <td width="72%"><input type="image" name="imageField3" src="images/reset.gif" /></td>
                          </tr>
                      </table></td>
                    </tr>
                  </table>
                                </form>
                </td>
                </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td valign="top"><table width="741" border="0" cellpadding="0" cellspacing="0" style="background-image:url(images/index_74.gif);">
          <tr>
            <td height="74"><pre><a href="index.html">About Us     </a> | <a href="content.html">    New Cars</a>     | <a href="content.html">    Dealers    </a> | <a href="content.html">    Services</a>     |     <a href="contact.html">Contact Us</a><br /><span class="style3">Copyright &copy; 2002-2006 Company.com. All Rights Reserved.</span></pre></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
@endsection

        @section('footer')
            @include('inc.footer')

        @endsection


