<?php

echo trans('Voiture::example.welcome');