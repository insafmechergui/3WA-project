<script src="//tags.tiqcdn.com/utag/avisbudgetgroup/avis-corp/prod/utag.sync.js"></script>
<script src="https://avisassets.abgemea.com/dms/custom-script/target/VisitorAPI.js"></script>
<script src="https://avisassets.abgemea.com/dms/custom-script/target/at.js"></script>

<script>
  if(top != self || top.location != self.location)
  {
    
    top.location.href == self.location.href;
  }
</script>

  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta charset="utf-8" />
     <meta name="keywords" content="Location de voiture casablanca, location de voiture 
<br/>
<br/>" />
  <meta name="description" content="Réservez dès maintenant une voiture de location à Casablanca au meilleur tarif avec Avis Maroc. Vous pouvez réserver en ligne, par téléphone ou en agence. Avis Casablanca est un acteur majeur de la location de voiture au Maroc à l&#039;expertise reconnue.
<br/>" />
  <meta name="author" content="Avis Car Hire" />
  <meta name="rating" content="GENERAL" />
  <meta name="HandheldFriendly" content="True">
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  
  
    <meta name="distribution" content="GLOBAL" />
      <meta name="Content-Language" content="FR" />
  <!-- BEGIN: Smart App Banner -->



<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/css/bootstrap.min.css" integrity="sha384-PDle/QlgIONtM1aqA2Qemk5gPOE7wFq8+Em+G/hmo5Iq0CCmYZLv3fVRDJ4MMwEA" crossorigin="anonymous">
 
  <!-- END: Smart App Banner -->
  

  
  <!-- Begin : Canonical URL Link availability -->
      <link rel="canonical" href="https://www.avis.ma/location-voiture-maroc/agences-centre-ville/location-voiture-casablanca"/>
  <!-- End : Canonical URL Link availability -->

  <!--[if IEMobile]>
      <meta http-equiv="cleartype" content="on">
    <![endif]-->
	
	<link rel="shortcut icon" href="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/img/favicons/favicon.ico" />
	<link rel="apple-touch-icon-precomposed" sizes="152x152" href="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/img/favicons/apple-touch-icon-152x152-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/img/favicons/apple-touch-icon-144x144-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="120x120" href="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/img/favicons/apple-touch-icon-120x120-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/img/favicons/apple-touch-icon-114x114-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="76x76" href="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/img/favicons/apple-touch-icon-76x76-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/img/favicons/apple-touch-icon-72x72-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="57x57" href="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/img/favicons/apple-touch-icon-57x57-precomposed.png">
	<link rel="apple-touch-icon-precomposed" href="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/img/favicons/apple-touch-icon-precomposed.png">
	<meta name="msapplication-TileColor" content="#D2002A">
	<meta name="msapplication-TileImage" content="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/img/favicons/msapp-icon-144x144-precomposed.png">
  
   <link rel="stylesheet" href="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/css/avenir02.css"/>
  
    <!-- CZ condition for fonts support -->
    <!--[if gt IE 8]><!-->
    <!-- INCLUDE baseline baseline CSS files here in build task defined order -->
    		<link rel="stylesheet" href="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/css/baseline.min.css?v=2.9.23" />   
    		<link rel="stylesheet" href="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/css/tablet.min.css?v=2.9.23" media="screen and (min-width: 581px)"/>   
    		<link rel="stylesheet" href="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/css/desktop.min.css?v=2.9.23" media="screen and (min-width: 959px)"/>   
    <!--<![endif]-->

    <!-- REPEAT larger screen major breakpoint CSS files here for IE 7,8 -->
    <!--[if lt IE 9 ]>
    <link rel="stylesheet" href="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/css/pre-ie9-baseline.min.css" media="screen" />
    <link rel="stylesheet" href="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/css/pre-ie9-tablet-desktop.min.css" media="screen" />
    <![endif]-->
<!-- Globalize JS  -->

 <script src="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/js/lib/globalize.js"></script>
 <!-- its should come in condition based on language/domain -->
 <!-- currency format -->
 <!-- currency format -->
       
     
<script>
 var currencyFormat = {
 
   currency : {
       pattern: ["-n $","n $"],
      separator: " ",
      delimiter:  ","
   
   }
 }
</script>


 <!-- currency format -->
 
  <script src="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/js/lib/globalize.culture.fr-MA.js"></script>
<script>

 var culture = "fr-MA", cultureSelector ="fr-MA" ;
 

                
                Globalize.culture[culture];
                if(Globalize.cultures[culture] == undefined)
                {
                                culture = "default";
                  Globalize.culture[culture];
                  cultureSelector  = "en";
                }
               Globalize.cultureSelector = cultureSelector ;
                console.log(culture);
                
                
         


</script>
<!-- Globalize JS  -->
    <script src="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/js/lib/modernizr-2.6.2-custom.min.js"></script>
  
 
  
<script type="text/template" id="newTNCpop">
<div id="abg-overlay" class="newTNCpopOverlay" tabindex="-1" role="dialog" aria-labelledby="overlay-title" style="-webkit-user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); touch-action: none;">
	<div class="contentpage-overlay-mask">
		<div class="contentpage-overlay-inner">
			<div class="contentpage-overlay-bg">
				<h2 id="overlay-title">Nouvelles Conditions générales</h2>
				<h4>Merci de télécharger le document PDF ci-dessous et de lire nos nouvelles conditions générales.</h4>
				<a href="#" class="close-overlay">
					<i data-icon="&#xe002;" aria-label="close the terms and conditions information"></i>
					Close
				</a>
				<div class="pdf-block">
					<a target="_blank" href="https://avisassets.abgemea.com/dms">					
						<img alt="pdf-icon" width="33px" height="41px" title="View/Download PDF" src="https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/img/pdficon.png"/>
						<span>CONDITIONS GENERALES (PDF)</span>
						<i aria-hidden="true" data-icon="&#xe004;"></i>
					</a>
				</div>
				<div class="form">
					<div class="form-row">
						<button class="submit-button" type="submit">Accepter<i data-icon="&#xe004;"></i></button>
						<button type="submit" class="primary-button">Decliner<i data-icon="&#xe004;"></i></button>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</script>  

   <script>
        var ABG = window.ABG || {
        	isCaptchaEnabled : false,
            highres : Modernizr.highres ? true : false,
            clickTouch : Modernizr.touch ? 'tap' : 'click',
            breakpoints : {
                mobile : "(max-width: 580px)",
                tablet : "(min-width: 581px)",
                desktop : "(min-width: 959px)"
            },
      fccAwdNumFlag :false,
      dateText : ["Date"],
            //container for form validation, data is added through HTML source
            validation : {
    
            },
    
            errorMessages : {
        beyondMaxRentalMsg :["Rental date selected is more than max rental days"],
               delDateGreater:["Nous sommes désolés, la date de début de votre location de voiture ne peut pas être ultérieure à la date de fin. Merci de vérifier et de recommencer."],
        delTimeGreater:["Nous sommes désolés, la date de ramassage ou de retour du véhicule ne peut pas être ultérieur à l'heure du dépôt. Merci de vérifier et de recommencer."],
            delTimeNoSlots:[""],
            choosePickup:["Veuillez choisir votre lieu de prise en charge. "],
        chooseDrop:["Veuillez choisir votre lieu de dépôt. "],
        chooseOthrPickUp:["Nous sommes désolés, nous ne reconnaissons pas ce lieu de dépôt. S'il vous plaît, vérifiez et essayez à nouveau. "],
        chooseOthrDropOff:["Nous sommes désolés, nous ne reconnaissons pas ce lieu de dépôt. S'il vous plaît, vérifiez et essayez à nouveau. "],
        changePrice :["Pour votre information, choisir cet horaire allonge votre location d'une journée étant donné que nous facturons par tranche de 24 heures. Si vous ne souhaitez pas payer pour une journée supplémentaire, merci de choisir un horaire plus tôt."],
        blackoutMsg:[""],
        leadTimeMsg:[""],
        incorrectWizardLength:   ["Sorry, the customer number entered is not correct. Please re-enter this number in the format: D12345"],
              modifyBooking:{
              tncNotChecked  :  ["Merci de cocher la case si vous avez pris connaissance des Conditions générales."],
              serviceError  :  [""],
              pickUpTimelt24hrs:   [""]
              },
        postcodeError:["Nous sommes désolés, nous n’avons trouvé aucun résultat. Veuillez recommencer ou appeler le (+212) 522 974 000."],
               loginEmailEmpty : ["Veuillez indiquer votre adresse électronique."],
                loginhidtextEmpty : ["Veuillez indiquer votre mot de passe."],
                 genericEmpty : ["Veuillez renseigner ce champ."],
                genericTryAgain : ["Veuillez réessayer."],
                invalidEmail : ["Nous sommes désolés, votre adresse électronique n’a pas pu être identifiée. Veuillez réessayer en utilisant ce format : bonjour@exemple.fr"],
                invalidhidtext : ["Nous sommes désolés, votre adresse électronique et votre mot de passe ne correspondent pas. Veuillez vérifier et réessayer."],
                emailEmpty: ["Merci de renseigner votre adresse électronique."],
                emailInvalid: ["Veuillez saisir votre adresse électronique en respectant le format suivant : bonjour@exemple.fr."],
                 emailExists:["Merci, mais vous êtes déjà inscrit."],
                 minAgeError:["Nous sommes désolés, la date de naissance saisie correspond à un âge plus jeune que l’âge minimum exigé. "],
                carRentalSearchFail : "The car search failed, please try again",
    
                hireLocationRequired : ["Veuillez sélectionner une agence de retrait."],
                returnLocationRequired : ["Veuillez sélectionner une agence de retour."],
                customerTypeRequired : ["Veuillez choisir le type de client"],
                
                locationClosedDay : ["This location isn't open on the day you've chosen.", "Select another day"],
                locationClosedTime : ["Nous sommes désolés, l’agence sera fermée. Veuillez sélectionner une heure différente. "],
    
                locationTimeInThePast : [""],
    
                locationNotOpen : "This location isn't open on this day.",
                locationSelectAnother : "Select another day or pick up point.",
                invalidBookingNumber: 'The booking number you entered isn�t a recognised format.',
                locationClosedDays:["Nous sommes désolés, l’agence sera fermée à la date/heure indiquée. Veuillez sélectionner un autre jour ou une autre agence."],
                nationalHolidays:["Nous sommes désolés, l’agence sera fermée à cette époque de l’année. Veuillez sélectionner une autre agence. "],
                not24hrsupoort:["Nous sommes désolés, l’agence sera fermée à votre retour. Veuillez sélectionner un autre horaire ou une autre agence."],
                support24hr:["Nous sommes désolés, l’agence sera fermée, mais vous pouvez rendre votre véhicule en déposant les clés dans notre boîte sécurisée. En revanche, vous serez responsable de tout dommage subi par le véhicule jusqu’à la réouverture de l’agence."],
                dropoffLocationClosedDay:["Nous sommes désolés, l’agence sera fermée à votre retour. Veuillez sélectionner un autre jour ou une autre agence. "],
                tableMessage : "Nous sommes désolés, aucune voiture n'est disponible pour ces dates. Veuillez indiquer une autre date ou une autre agence, ou appeler le (+212) 522 974 000.",
        AWDValidate: ["Nous sommes désolés mais votre numéro AWD n'est pas valide. Merci de réessayer avec le format suivant : D123456."],
                wizNumber :["Nous sommes désolés, le numéro client saisi n'est pas correct. Merci de réessayer avec le format suivant '3ZZ33Z'. "],
                surName : [""],
                wizNumberBck : ["Nous sommes désolés, votre nom de famille ne correspond pas à votre profil client. Veuillez vérifier et réessayer."],
                surNameBck : ["Nous sommes désolés, votre nom de famille ne correspond pas à votre profil client. Veuillez vérifier et réessayer."],
        surNameNull : ["Veuillez renseigner votre nom de famille."],
        billingDetails: {
          companyName : ["Nous sommes désolés, cette entreprise n’a pas pu être identifiée. Veuillez réessayer en utilisant uniquement des chiffres, des lettres et des espaces."],
          address : ["Nous sommes désolés, cette adresse n’a pas pu être identifiée. Veuillez réessayer en utilisant des chiffres, des lettres, des espaces et les caractères - # . , ; : ’ °&()/ uniquement."],
          city : ["Nous sommes désolés, ce lieu n’a pas pu être identifié. Veuillez réessayer en utilisant les caractères A-Z, a-z, 1-9 et les espaces, ainsi que les caractères - # . ; ’ & / . ( ) uniquement."],
          postCode : ["Nous sommes désolés, ce code postal n’a pas pu être identifié. Veuillez réessayer en utilisant uniquement des chiffres, des lettres et des espaces."],
          county : ["Nous sommes désolés, le département n’a pas pu être identifié. Veuillez réessayer en utilisant uniquement des chiffres, des lettres et des espaces."],
          clendarMsg :["Pour les locations de plus de <span>90</span> jour(s), merci de consulter nos solutions de <a href='/bons-plans-location-voiture-maroc/location-voiture-au-mois' </a>"]
        },
        billingDetailsMandate:{        
          address : ["Veuillez nous indiquer la première ligne de votre adresse"],
          city : ["Veuillez indiquer votre ville."],
          postCode : ["Veuillez renseigner votre code postal. Si votre adresse n’a pas de code postal, veuillez écrire XXXXX dans la case correspondante."]
        }
            },
    
            urls : {
        shopURL: 'https://secure.avis.ma',
        baseURL: 'https://www.avis.ma',
                basePath  :'https://www.avis.ma',
        tealiumURL: '//tags.tiqcdn.com/utag/avisbudgetgroup/avisma/prod/utag.js',
            contextPath: '',
                contextPathLocal : '',
        contextPathLocale : 'fr_MA',
                carRentalSearch : 'https://secure.avis.ma/JsonProviderServlet/fr_MA', //used for autocomplete/lookahead
                locationGeoSearch : 'https://avisassets.abgemea.com/.resources/htmlTemplates/stubs/station-results.json', //used for geolocation requests on m.m.19
                homePageMobile : 'https://avisassets.abgemea.com/.resources/htmlTemplates/pages/P_D_03_home-page/index.shtml?device=mobile', // Replace with production homepage url
                 mapPageMobile :  'https://secure.avis.ma/proximity-map?device=mobile', // Replace with production mobile map view page url
                    billingLocationSearch : 'https://secure.avis.ma/JsonProviderServlet/fr_MA?requestType=addr-search', //used for payment lookahead
                deliveryLocationSearch : 'https://avisassets.abgemea.com/.resources/htmlTemplates/stubs/m_d_30_extras-delivery-location-search.json', //used for delivery postcode/address lookahead
                  youngDriverSurcharge : 'https://secure.avis.ma/JsonProviderServlet/fr_MA?requestType=youngDriverSurcharge',
                    newsletterSignup: 'https://secure.avis.ma/JsonProviderServlet/fr_MA?requestType=newsletter',
                    newsletterSubscribe: 'https://secure.avis.ma/JsonProviderServlet/fr_MA?requestType=newsletterSubscribe',
                      forgothidtext: 'https://secure.avis.ma/JsonProviderServlet/fr_MA?requestType=forgothidtext',
        privacyTermsAjax :'https://secure.avis.ma/JsonProviderServlet/fr_MA',
          deliveryCollectionLoc : 'https://secure.avis.ma/JsonProviderServlet/fr_MA?requestType=dnc',
            resendEmail: 'https://secure.avis.ma/JsonProviderServlet/fr_MA?requestType=resendmail',
              fcc:'https://secure.avis.ma/JsonProviderServlet/fr_MA?requestType=fcc',
              avisPreferredURL: "avis-preferred",
              avisBasicURL: "avisBasic"
            },
    
            extras :  {
                childSeatInPackageID :  'child-seat-in-package'
            },
    
            map : {
                credentials : 'Ajw7IfaSsJGGljeccmtYvvBTgb6_uEk3QqBr7XMZ8qwxcImKMPB9yZziOj1Gvo-0', // Replace with the genuine AVIS key, as this key is trial only which expries on 11/17/2013
                defaults : { // Tailor these details per region as commented out below
                  // language : 'fr-MA',
                  //  latitude : 54.524270,
                  //   longitude : -4.130859,
                  //   zoom: 5
    
                    // GERMANY
                    // language : 'de-DE',
                    // latitude : 51.301557,
                    // longitude : 10.390625,
                    // zoom: 6
    
                    // SPAIN
                     language : 'fr-MA',
                     latitude : 31.791702,
                       longitude : -7.092620,
                      zoom: 5.0
                       
                  // language : 'es-ES',
                           // latitude : 40.294349,
                       //longitude : -3.847656,
                       //zoom: 6  
                       
                       
                       
                    // FRANCE
                    // language : 'fr-FR',
                    // latitude : 46.511768,
                    // longitude : 1.997070,
                    // zoom: 6
    
                    // ITALY
                    // language : 'it-IT',
                    // latitude : 42.599750,
                    // longitude : 12.038574,
                    // zoom: 5
                },
                pins : {
                    station : {
                        path : 'https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/img/icons/station-pin.png',
                        height : 36,
                        width : 36,
                        anchorOffsetX: 18,
                        anchorOffsetY: 18
                    },
                    stationActive : {
                        path : 'https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/img/icons/station-active-pin.png',
                        height : 31,
                        width : 24,
                        anchorOffsetX: 16,
                        anchorOffsetY: 27
                    },
                    user : {
                        path : 'https://avisassets.abgemea.com/resources/templating-kit/themes/avis-digital/img/icons/user-pin.png',
                        height : 36,
                        width : 36,
                        anchorOffsetX: 18,
                        anchorOffsetY: 18
                    }
                }
            },
    
            userSession : {
          sessionTime : 60, //mins
          sessionBufferTime : 5, //mins
        rentalDays : 2
            },
    
            calendar : {
    
                startDayOffset : 0, // from today, dont change this value..
        tDateOffset : 1, // this value should be configurable
        
                defaultDayRange : 2,                 
                maxRentalPeriod : 90,
    
                mobileMonths : 1,
    
                tabletMonths : 2,
    
                desktopMonths : 3,
            datePickup : true,
             dateDrop : true,
                extraDayThreshold : 0, // 15, 30, 45, 100 (use 100 for full hour comparing 24 hr time subtraction)
                dayNamesShort :Globalize.cultures[culture].calendars.standard.days.namesShort,
                dayNamesMid :Globalize.cultures[culture].calendars.standard.days.namesAbbr,
                dayNamesLong :Globalize.cultures[culture].calendars.standard.days.names, 
                monthNamesShort :Globalize.cultures[culture].calendars.standard.months.namesAbbr,
                monthNamesLong : Globalize.cultures[culture].calendars.standard.months.names,
                isSiteRTL : false
            }
    
            ,isMobile :  false,
      searchIp : false,
      keyUpDelay : 400.0,
            dayRental : "Jours de Location",
      dayRentals :"jours de location",
      prevText :"précédent",
      calenMonths : "mois",
      nextText: "Prochain",
      mapScrollPickup : true,
            mapScrolldrop : true,
      bookingPagination : "6",
           awdPopUp:false,
           bannerHidden:15 ,      
      flow:'false',
      homePageFlag:false,
      pickUp :"DÉPART",
      returnLabel :"RETOUR",
      startDate :"DATE DE DÉPART",
      returnDate :"DATE DE RETOUR",
      errorE0016 : "",
      mapLoad : "false",
      checkPopUpMsgEnable : false,
	  included : "Included",
	  isDeepLinking: false,
      isPartnerSite : false
        }
    
    </script>
