<?php 

return [
    'welcome' => 'Welcome, this is User module.'
];
