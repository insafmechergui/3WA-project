<?php 

return [
    'welcome' => 'Welcome, this is Annonce module.'
];
