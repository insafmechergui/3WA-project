            <div class="top-bar">
                <div class="container">
                    <div class="row">
                        
                        
                              <div class="col-lg-6 col-md-6 col-sm-6 col-6">
                                <address class="contact-num">
                                  <?php if(Auth::user()): ?>

                                    <span><i class="fa fa-phone"></i> <?php echo e(Auth::user()->phone); ?></span>
                                  <?php endif; ?>
                                    
                                </address>
                              </div>
                               <div class="col-lg-6 col-md-6 col-sm-6 col-6" style="color: white;">
                          <?php if(Auth::user()): ?>

                            <span class="login-form">
                                <?php if(Auth::user()->photo): ?>
                                <a href="<?php echo e(route('afficherProfil',[Auth::user()->id])); ?>">

                                    <img src="<?php echo e(asset('/')); ?>storage/<?php echo e(Auth::user()->photo); ?>" alt="" style="width: 5%;border-radius: 40%;">
                                </a>
                                <?php else: ?>
                                <img src="<?php echo e(asset('assets/images/user2.jpg')); ?>" alt="" style="width: 5%;border-radius: 40%;">
                                <?php endif; ?>
                            </span>
                                <strong>Salut <?php echo e(Auth::user()->name); ?></strong>

                            <div class="log-details">

                            <a href="<?php echo e(route('handleLogOut')); ?>">Déconnexion</a>
                            </div><!--log-details end-->

                        <?php else: ?>
                            <span>Veuillez se connecter</span>                       
                            <div class="log-details">
                                <span class="login-form"><i class="la la-user"></i> <b>Login</b>/<b>Register</b></span>
                            </div><!--log-details end-->
                        <?php endif; ?>
                        </div>

                            </div><!--wrapper end-->                           

                    </div>
            </div><!--top-bar end-->
            <div class="bottom-header">
                <div class="container">
                    <div class="navigation text-right">
                        <nav>
                            <ul>
                                <li><a href="<?php echo e(route('showHome')); ?>" title="">Home</a></li>
                                <li><a href="<?php echo e(route('showListing')); ?>" title="">Properties</a></li>
                            </ul>
                        </nav>
                    </div><!--navigation end-->
                    <div class="logo text-center">
                        <a href="" title="">
                            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="">
                        </a>
                    </div>
                    <div class="navigation float-right text-left">
                        <nav>
                            <ul>
                               <li><a href="<?php echo e(route('showAgent')); ?>" title="">Agents</a></li>
                                <li><a href="<?php echo e(route('handleContact')); ?>" title="">Contact</a></li>
                        <?php if(Auth::user()): ?>
                                <li><a href="<?php echo e(route('showHomeAnnonce')); ?>" title="">Ajouter une annonce</a></li>
                        <?php endif; ?>

                            </ul>
                        </nav>
                    </div>
                    <div class="menu-btn">
                        <a href="#" title="">
                            <span class="bar1"></span>
                            <span class="bar2"></span>
                            <span class="bar3"></span>
                        </a>
                    </div><!--menu-btn end-->
                </div>
            </div><!--bottom-header end-->
             <div class="responsive-mobile-menu">
            <ul>
                <li><a class="active" href="<?php echo e(route('showHome')); ?>" title="">Home</a></li>
                <li><a href="<?php echo e(route('showListing')); ?>" title="">Properties</a></li>
                    
                <li><a href="<?php echo e(route('showAgent')); ?>" title="">Agents</a></li>
                
                <li><a href="<?php echo e(route('handleContact')); ?>" title="">Contact</a></li>
                <li><a href="#" title="">Buy Template</a></li>
            <?php if(Auth::user()): ?>
                <li><a href="<?php echo e(route('showHomeAnnonce')); ?>" title="">Ajouter une annonce</a></li>
            <?php endif; ?>
            </ul>
        </div><!--responsive-mobile-menu end-->
