<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <?php echo $__env->yieldContent('head'); ?>

</head>

<body>
    <header>     <?php echo $__env->yieldContent('header'); ?>   </header>
   
        <?php echo $__env->yieldContent('content'); ?>

       <?php echo $__env->yieldContent('footer'); ?>  



</body>

</html>