<script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/custom-select.js"></script>
    <script src="assets/js/handleCounter.js"></script>
    <!-- Maps -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB0lxCRSHcNPBu5hq3wsmY1KhcBq5Tlwi8"></script>
    <script src="assets/js/map-cluster/infobox.min.js"></script>
    <script src="assets/js/map-cluster/markerclusterer.js"></script>
    <script src="assets/js/map-cluster/maps.js"></script>
    <!-- Custom Js Script File -->
    <script src="assets/js/scripts.js"></script>

     
