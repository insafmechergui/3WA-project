<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('inc.head',['title'=>'accueil'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
            <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <div class="responsive-mobile-menu">
            <ul>
                <li><a href="01_Home.html" title="">Home</a>
                    <ul>
                        <li class="active"><a href="29_Home_Alternative.html" title="">Home Alternative</a></li>
                    </ul>
                </li>
                <li><a class="active" href="#" title="">Properties</a>
                    <ul>
                        <li><a href="04_Properties_Grid_Map_Standart_Alternative.html" title="">Properties Grid Standart</a></li>
                        <li><a href="03_Properties_Grid_Map_Full_Width.html" title="">Properties Grid Full Width</a></li>
                        <li><a href="05_Properties_Grid_Map_Full_Width_Alternative.html" title="">Properties Grid Alternative</a></li>
                        <li><a href="06_Properties_Half_Grid_Map_View.html" title="">Properties Grid Half Map</a></li>
                        <li><a href="07_Properties_List_Map_Standart.html" title="">Properties List Standart</a></li>
                        <li><a href="08_Properties_Half_List_Map_View.html" title="">Properties List Half Map</a></li>
                        <li><a href="<?php echo e(route('singlelisting')); ?>" title="">Single Properties</a></li>
                    </ul>
                </li>
                <li><a href="agents.html" title="">Agents</a></li>
                <li><a href="#" title="">Pages</a>
                    <ul>
                        <li><h3>Column Menu 1</h3></li>
                        <li><a href="04_Properties_Grid_Map_Standart_Alternative.html" title="">Properties Grid Standart</a></li>
                        <li><a href="03_Properties_Grid_Map_Full_Width.html" title="">Properties Grid Map Full Width</a></li>
                        <li><a href="05_Properties_Grid_Map_Full_Width_Alternative.html" title="">Properties Grid Alternative</a></li>
                        <li><a href="06_Properties_Half_Grid_Map_View.html" title="">Properties Grid Half Map</a></li>
                        <li><a href="07_Properties_List_Map_Standart.html" title="">Properties List Standart</a></li>
                        <li><a href="08_Properties_Half_List_Map_View.html" title="">Properties List Half Map</a></li>
                        <li><h3>Column Menu 2</h3></li>
                        <li class="active"><a href="09_Properties_Grid_Map_Hover.html" title="">Properties Grid Map Hover</a></li>
                        <li><a href="10_Properties_Half_Map_Grid_View_Full_Screen.html" title="">Properties Half Full Screen</a></li>
                        <li><a href="28_Properties_Half_List_Geo_Version_With_Geo_Map.html" title="">Properties  Geo Version </a></li>
                        <li><a href="<?php echo e(route('singlelisting')); ?>" title="">Single Properties Standart</a></li>
                        <li><a href="12_Single_Properties_Image_Full_Width.html" title="">Single Properties Full Width</a></li>
                        <li><a href="13_Single_Properties_Gallery_Images.html" title="">Single Properties Gallery</a></li>
                        <li><h3>Column Menu 3</h3></li>
                        <li><a href="18_Blog_Gallery.html" title="">Blog Standart</a></li>
                        <li><a href="15_Blog_Full_Width_Alternative.html" title="">Blog Full Width Alternative</a></li>
                        <li><a href="14_Blog_Grid.html" title="">Blog Grid 3 Column</a></li>
                        <li><a href="18_Blog_Gallery.html" title="">Blog Open Gallery</a></li>
                    </ul>
                </li>
                <li><a href="20_Contact.html" title="">Contact</a></li>
                <li><a href="#" title="">Buy Template</a></li>
            </ul>
        </div><!--responsive-mobile-menu end-->

        <section id="map-container" class="fullwidth-home-map">
            <h2 class="vis-hid">section heading</h2>
            <div id="map" data-map-zoom="9"></div>
        </section>

        <section class="page-content sec-padding">
            <div class="container">
                <div class="page-content-details">
                    <div class="row">
                        <div class="col-xl-8 col-lg-12">
                            <div class="listing-sec">
                                <div class="listing-control-head">
                                    <form>
                                        <div class="form-field">
                                            <div class="custom-select">
                                                <select>
                                                    <option value="0">Default Order</option>
                                                    <option value="1">By publish date ASC</option>
                                                    <option value="2">By publish date DESC</option>
                                                    <option value="3">By price ASC</option>
                                                    <option value="4">By price DESC</option>
                                                </select>
                                            </div>
                                        </div><!--form-field end-->
                                    </form>
                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" id="vertical-tab" data-toggle="tab" href="#vertical-post" role="tab" aria-controls="vertical-post" aria-selected="true"><i class="fa fa-th"></i></a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="horizental-tab" data-toggle="tab" href="#horizental-post" role="tab" aria-controls="horizental-post" aria-selected="true"><i class="fa fa-list-ul"></i></a>
                                        </li>
                                    </ul>
                                </div><!--listing-control-head end-->
                                <div class="listing-items pc-tg-right">
                                    <div class="tab-content">
                                        <div class="tab-pane fade show active" id="vertical-post" role="tabpanel" aria-labelledby="vertical-tab">
                                            <div class="sales-items">
                                                <div class="row">
                                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                                        <div class="sale-item">
                                                            <div class="item-img">
                                                                <img src="assets/images/single-img.jpg" alt="">
                                                                <span class="item-status">For Sale</span>
                                                                <a href="<?php echo e(route('singlelisting')); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="item-info">
                                                                <h3><a href="<?php echo e(route('singlelisting')); ?>" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div><!--sale-item end-->
                                                    </div>
                                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                                        <div class="sale-item">
                                                            <div class="item-img">
                                                                <img src="assets/images/single-img.jpg" alt="">
                                                                <span class="item-status">For Sale</span>
                                                                <a href="<?php echo e(route('singlelisting')); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="item-info">
                                                                <h3><a href="<?php echo e(route('singlelisting')); ?>" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div><!--sale-item end-->
                                                    </div>
                                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                                        <div class="sale-item">
                                                            <div class="item-img">
                                                                <img src="assets/images/single-img.jpg" alt="">
                                                                <span class="item-status">For Sale</span>
                                                                <a href="<?php echo e(route('singlelisting')); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="item-info">
                                                                <h3><a href="<?php echo e(route('singlelisting')); ?>" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div><!--sale-item end-->
                                                    </div>
                                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                                        <div class="sale-item">
                                                            <div class="item-img">
                                                                <img src="assets/images/single-img.jpg" alt="">
                                                                <span class="item-status">For Sale</span>
                                                                <a href="<?php echo e(route('singlelisting')); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="item-info">
                                                                <h3><a href="<?php echo e(route('singlelisting')); ?>" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div><!--sale-item end-->
                                                    </div>
                                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                                        <div class="sale-item">
                                                            <div class="item-img">
                                                                <img src="assets/images/single-img.jpg" alt="">
                                                                <span class="item-status">For Sale</span>
                                                                <a href="<?php echo e(route('singlelisting')); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="item-info">
                                                                <h3><a href="<?php echo e(route('singlelisting')); ?>" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div><!--sale-item end-->
                                                    </div>
                                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                                        <div class="sale-item">
                                                            <div class="item-img">
                                                                <img src="assets/images/single-img.jpg" alt="">
                                                                <span class="item-status">For Sale</span>
                                                                <a href="<?php echo e(route('singlelisting')); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="item-info">
                                                                <h3><a href="<?php echo e(route('singlelisting')); ?>" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div><!--sale-item end-->
                                                    </div>
                                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                                        <div class="sale-item">
                                                            <div class="item-img">
                                                                <img src="assets/images/single-img.jpg" alt="">
                                                                <span class="item-status">For Sale</span>
                                                                <a href="<?php echo e(route('singlelisting')); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="item-info">
                                                                <h3><a href="<?php echo e(route('singlelisting')); ?>" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div><!--sale-item end-->
                                                    </div>
                                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                                        <div class="sale-item">
                                                            <div class="item-img">
                                                                <img src="assets/images/single-img.jpg" alt="">
                                                                <span class="item-status">For Sale</span>
                                                                <a href="<?php echo e(route('singlelisting')); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="item-info">
                                                                <h3><a href="<?php echo e(route('singlelisting')); ?>" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div><!--sale-item end-->
                                                    </div>
                                                </div>
                                            </div><!--sales-items end-->
                                        </div>
                                        <div class="tab-pane fade" id="horizental-post" role="tabpanel" aria-labelledby="horizental-tab">
                                            <div class="sales-items horizental-view">
                                                <div class="sale-item">
                                                    <div class="row">
                                                        <div class="col-lg-4 col-md-4 col-sm-4">
                                                            <div class="item-img">
                                                                <img src="assets/images/single-img.jpg" alt="">
                                                                <span class="item-status">For Sale</span>
                                                                <a href="<?php echo e(route('singlelisting')); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div><!--item-img end-->
                                                        </div>
                                                        <div class="col-lg-8 col-md-8 col-sm-8">
                                                            <div class="item-info">
                                                                <h3><a href="<?php echo e(route('singlelisting')); ?>" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisielit quat ipsum, nec sagittis sem nibh id elit. Morbi accumsan sum velit. </p>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div>
                                                    </div>
                                                </div><!--sale-item end-->
                                                <div class="sale-item">
                                                    <div class="row">
                                                        <div class="col-lg-4 col-md-4 col-sm-4">
                                                            <div class="item-img">
                                                                <img src="assets/images/single-img.jpg" alt="">
                                                                <span class="item-status">For Sale</span>
                                                                <a href="<?php echo e(route('singlelisting')); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div><!--item-img end-->
                                                        </div>
                                                        <div class="col-lg-8 col-md-8 col-sm-8">
                                                            <div class="item-info">
                                                                <h3><a href="<?php echo e(route('singlelisting')); ?>" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisielit quat ipsum, nec sagittis sem nibh id elit. Morbi accumsan sum velit. </p>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div>
                                                    </div>
                                                </div><!--sale-item end-->
                                                <div class="sale-item">
                                                    <div class="row">
                                                        <div class="col-lg-4 col-md-4 col-sm-4">
                                                            <div class="item-img">
                                                                <img src="assets/images/single-img.jpg" alt="">
                                                                <span class="item-status">For Sale</span>
                                                                <a href="<?php echo e(route('singlelisting')); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div><!--item-img end-->
                                                        </div>
                                                        <div class="col-lg-8 col-md-8 col-sm-8">
                                                            <div class="item-info">
                                                                <h3><a href="<?php echo e(route('singlelisting')); ?>" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisielit quat ipsum, nec sagittis sem nibh id elit. Morbi accumsan sum velit. </p>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div>
                                                    </div>
                                                </div><!--sale-item end-->
                                                <div class="sale-item">
                                                    <div class="row">
                                                        <div class="col-lg-4 col-md-4 col-sm-4">
                                                            <div class="item-img">
                                                                <img src="assets/images/single-img.jpg" alt="">
                                                                <span class="item-status">For Sale</span>
                                                                <a href="<?php echo e(route('singlelisting')); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div><!--item-img end-->
                                                        </div>
                                                        <div class="col-lg-8 col-md-8 col-sm-8">
                                                            <div class="item-info">
                                                                <h3><a href="<?php echo e(route('singlelisting')); ?>" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisielit quat ipsum, nec sagittis sem nibh id elit. Morbi accumsan sum velit. </p>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div>
                                                    </div>
                                                </div><!--sale-item end-->
                                                <div class="sale-item">
                                                    <div class="row">
                                                        <div class="col-lg-4 col-md-4 col-sm-4">
                                                            <div class="item-img">
                                                                <img src="assets/images/resources/img8.jpg" alt="">
                                                                <span class="item-status">For Sale</span>
                                                                <a href="<?php echo e(route('singlelisting')); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div><!--item-img end-->
                                                        </div>
                                                        <div class="col-lg-8 col-md-8 col-sm-8">
                                                            <div class="item-info">
                                                                <h3><a href="<?php echo e(route('singlelisting')); ?>" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisielit quat ipsum, nec sagittis sem nibh id elit. Morbi accumsan sum velit. </p>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div>
                                                    </div>
                                                </div><!--sale-item end-->
                                                <div class="sale-item">
                                                    <div class="row">
                                                        <div class="col-lg-4 col-md-4 col-sm-4">
                                                            <div class="item-img">
                                                                <img src="assets/images/resources/img9.jpg" alt="">
                                                                <span class="item-status">For Sale</span>
                                                                <a href="<?php echo e(route('singlelisting')); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div><!--item-img end-->
                                                        </div>
                                                        <div class="col-lg-8 col-md-8 col-sm-8">
                                                            <div class="item-info">
                                                                <h3><a href="<?php echo e(route('singlelisting')); ?>" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisielit quat ipsum, nec sagittis sem nibh id elit. Morbi accumsan sum velit. </p>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div>
                                                    </div>
                                                </div><!--sale-item end-->
                                                <div class="sale-item">
                                                    <div class="row">
                                                        <div class="col-lg-4 col-md-4 col-sm-4">
                                                            <div class="item-img">
                                                                <img src="assets/images/resources/img10.jpg" alt="">
                                                                <span class="item-status">For Sale</span>
                                                                <a href="<?php echo e(route('singlelisting')); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div><!--item-img end-->
                                                        </div>
                                                        <div class="col-lg-8 col-md-8 col-sm-8">
                                                            <div class="item-info">
                                                                <h3><a href="<?php echo e(route('singlelisting')); ?>" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisielit quat ipsum, nec sagittis sem nibh id elit. Morbi accumsan sum velit. </p>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div>
                                                    </div>
                                                </div><!--sale-item end-->
                                            </div><!--sales-items end-->
                                        </div>
                                    </div>
                                </div><!--listing-items end-->
                                <div class="mai-pagination">
                                    <nav aria-label="Page navigation example">
                                        <ul class="pagination justify-content-center">
                                            <li class="page-item disabled">
                                              <a class="page-link" href="#" tabindex="-1"><i class="fa fa-angle-left"></i></a>
                                            </li>
                                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                                            <li class="page-item">
                                              <a class="page-link" href="#"><i class="fa fa-angle-right"></i></a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div><!--PAGINATION END-->
                            </div><!--listing-sec end-->
                        </div>
                        <div class="col-xl-4 col-lg-12 pl-35">
                            <div class="sidebar">
                                <div class="widget widget-search-properties">
                                    <h3 class="widget-title">Search Properties</h3>
                                    <form>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="form-field">
                                                    <label>All Location</label>
                                                    <div class="custom-select">
                                                        <select>
                                                            <option value="0">All Location</option>
                                                            <option value="1">California</option>
                                                            <option value="2">New York</option>
                                                            <option value="3">Chicago</option>
                                                            <option value="4">Las Vegas</option>
                                                            <option value="5">Fullerton</option>
                                                        </select>
                                                    </div>
                                                </div><!--form-field end-->
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="form-field">
                                                    <label>Property Type</label>
                                                    <div class="custom-select">
                                                        <select>
                                                            <option value="0">All Property Types</option>
                                                            <option value="1">Property type 1</option>
                                                            <option value="2">Property type 2</option>
                                                            <option value="3">Property type 3</option>
                                                            <option value="4">Property type 4</option>
                                                        </select>
                                                    </div>
                                                </div><!--form-field end-->
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="form-field">
                                                    <label>Status</label>
                                                    <div class="custom-select">
                                                        <select>
                                                            <option value="0">All Statuses</option>
                                                            <option value="1">Status 1</option>
                                                            <option value="2">Status 2</option>
                                                            <option value="3">Status 3</option>
                                                            <option value="4">Status 4</option>
                                                        </select>
                                                    </div>
                                                </div><!--form-field end-->
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-field">
                                                    <label>Price from</label>
                                                    <div class="handle-counter" id="handleCounter">
                                                        <input type="text" value="50">
                                                        <ul>
                                                            <li><button class="counter-minus btn"><i class="fa fa-caret-up"></i></button></li>
                                                            <li><button class="counter-plus btn"><i class="fa fa-caret-down"></i></button></li>
                                                        </ul>
                                                    </div>
                                                </div><!--form-field end-->
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-field">
                                                    <label>Price to</label>
                                                    <div class="handle-counter" id="handleCounter2">
                                                        <input type="text" value="60">
                                                        <ul>
                                                            <li><button class="counter-minus btn"><i class="fa fa-caret-up"></i></button></li>
                                                            <li><button class="counter-plus btn"><i class="fa fa-caret-down"></i></button></li>
                                                        </ul>
                                                    </div>
                                                </div><!--form-field end-->
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-field">
                                                    <label>Baths</label>
                                                    <div class="custom-select">
                                                        <select>
                                                            <option value="0">Any</option>
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                        </select>
                                                    </div>
                                                </div><!--form-field end-->
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-field">
                                                    <label>Beds</label>
                                                    <div class="custom-select">
                                                        <select>
                                                            <option value="0">Any</option>
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                        </select>
                                                    </div>
                                                </div><!--form-field end-->
                                            </div>
                                            <div class="col-lg-12">
                                                <button type="submit" class="lnk-default">Filter</button>
                                            </div>
                                        </div>
                                    </form>
                                </div><!--widget-search-properties end-->
                                <div class="widget widget-featured-propt">
                                    <h3 class="widget-title">Featured Properties</h3> 
                                    <div class="sale-item">
                                        <div class="item-img">
                                            <img src="assets/images/resources/ft-img1.jpg" alt="">
                                        </div>
                                        <div class="item-info">
                                            <div class="specs-info">
                                                <ul>
                                                    <li>Beds: 4 </li>
                                                    <li>Sqft: 1,570</li>
                                                </ul>
                                                <strong class="item-price">$499,500</strong>
                                            </div><!--specs-info end-->
                                        </div><!--item-info end-->
                                    </div>
                                </div><!--widget-featured-propt end-->
                            </div><!--sidebar end-->
                        </div>
                    </div>
                </div><!--page-content-details end-->
            </div>
        </section><!--page-content end-->

        <section class="subscribe-sec">
            <div class="container">
                <div class="subscribe-sec-details">
                    <h3>Find your perfect home</h3>
                    <a href="#" title="" class="lnk-default">Search NOW</a>
                </div><!--subscribe-sec-details end-->
            </div>
        </section><!--subscribe-sec end-->
        


<?php $__env->stopSection(); ?>

        <?php $__env->startSection('footer'); ?>
            <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>

        
    <?php $__env->startSection('script'); ?>
            <?php echo $__env->make('inc.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>