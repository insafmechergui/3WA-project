<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('inc.head',['title'=>'les Annonces'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
            <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 
    <div class="wrapper">

        

        <section class="page-content sec-padding">
            <div class="container">
                <div class="page-content-details">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12">
                            <div class="listing-sec">
                                
                                <div class="listing-items pc-tg-right">
                                    <div class="tab-content">
                                        <div class="tab-pane fade show active" id="vertical-post" role="tabpanel" aria-labelledby="vertical-tab">
                                            <div class="sales-items">
                                                <div class="row">
                                                    <?php $__currentLoopData = $listing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                                        <div class="sale-item">
                                                            <div class="item-img">
                                                                
                                                                    <?php if(count($list->medias)>0): ?>
                                                                        <img src="<?php echo e(asset('storage/'.$list->medias->first()->url)); ?>" alt="titre">
                                                                    <?php else: ?>
                                                                
                                                                    <img src="<?php echo e(asset('assets/images/user.jpg')); ?>" alt="">
                                                                <?php endif; ?>
                                                                <span class="item-status"><?php echo e($list->type); ?></span>
                                                                <a href="<?php echo e(route('showSingle',$list->id)); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="item-info">
                                                                <h3><a href="" title=""><?php echo e($list->titre); ?></a></h3>
                                                                <span><?php echo e($list->etat); ?></span>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price"><?php echo e($list->prix); ?> DT</strong>
                                                                    
                                                                    <p><?php echo e($list->count_visit); ?> vue(s)</p>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                            
                                                        </div><!--sale-item end-->

                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </div><!--sale-item end-->
                                                
                                            </div><!--sales-items end-->
                                        </div>
                                    </div>
                                </div><!--listing-items end-->
                              
                            </div>
                        </div><!--page-content-details end-->
                    </div>
                </div>
            </div>
        </section><!--page-content end-->

       
        
</div>

<?php $__env->stopSection(); ?>

        <?php $__env->startSection('footer'); ?>
            <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>