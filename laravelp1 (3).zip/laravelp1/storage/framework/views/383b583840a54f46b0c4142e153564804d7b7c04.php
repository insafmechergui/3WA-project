<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('inc.head',['title'=>'accueil'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
            <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper">

        <section class="main-banner-sec overlay">
            <div class="container">
                <div class="banner-details text-center">
                    <h2>Find your future home</h2>
                    <p>Where you can find happiness</p>
                    <form  class="navbar-search " method="post" action="<?php echo e(route('recherche')); ?>">
                        <div class="form-field">
                            <input name="titre" type="search" class="search-query" placeholder="search"> 
                             
                            <button type="submit" class="btn "><i class="fas fa-search"></i></button>
                        </div><!--form-field end-->
                        <?php echo e(csrf_field()); ?>

                    </form>
                        
                </div><!--banner-details end-->
            </div>
        </section><!--main-banner-sec end-->
        <section class="categories-sec sec-padding">
            <div class="container">
                <div class="sec-title text-center">
                    <h3>Categories</h3>
                </div><!--sec-title end-->
                <div class="categories-sec-details">
                    <div class="row">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-lg-4 col-md-6 col-sm-6">

                            <div class="category-info overlay">
                                <img src="<?php echo e(asset('assets/images/'.$cat->photo)); ?>" alt="category">
                                <a href="<?php echo e(route('showCategory',$cat->id)); ?>" title="" class="ext-link"></a>
                                <div class="category-details">
                                    <span><i class="la la-certificate"></i></span>
                                    <div class="cat-info">
                                        <h3><a href="" title=""><?php echo e($cat->name); ?></a></h3>
                                    </div>
                                </div><!--category-details end-->
                   
                            <span><?php echo e(count($cat->annonce)); ?> Annonce(s)</span>

                            </div><!--category-info end-->

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div><!--categories-sec-details end-->
            </div>
        </section><!--categories-sec end-->

        <section class="sale-items-sec sec-padding">
            <div class="container-fluid">
                <div class="sec-title text-center">
                    <h3>Latest For sale</h3>
                </div><!--sec-title end-->
                <div class="sales-items">
                    <div class="row">
                       <?php $__currentLoopData = $annonce; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ann): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                            <div class="sale-item">
                                <div class="item-img over_lay">
                                    <a href="" title="" class="ext-link">
                                        <?php if(count($ann->medias)>0): ?>
                                            <img src="<?php echo e(asset('storage/'.$ann->medias->first()->url)); ?>" alt="" >
                                        <?php endif; ?>
                                    </a>                                        
                                    <span class="item-status"><?php echo e($ann->type); ?></span>
                                </div>
                                <div class="item-info">
                                    <h3><a href="11_Single_Properties_Standart.html" title=""><?php echo e($ann->titre); ?></a></h3>
                                    <span><?php echo e($ann->etat); ?></span>
                                    <div class="specs-info">
                                        <ul>
                                            <li>Beds: 4 </li>
                                            <li>Baths: 2 </li>
                                            <li>Sqft: 1,570</li>
                                        </ul>
                                        <strong class="item-price"><?php echo e($ann->prix); ?> DT</strong>
                                    </div><!--specs-info end-->
                                </div><!--item-info end-->
                            </div><!--sale-item end-->
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div><!--sales-items end-->
            </div>
        </section><!--sale-items-sec end-->



        <section class="team-sec sec-padding">
            <div class="container">
                <div class="sec-title text-center">
                    <h3>Our Team</h3>
                </div><!--sec-title end-->
                <div class="team-sec-details">
                    <div class="row">
                       <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-4 col-sm-6">
                            <div class="team">
                                <div class="member-img">
                                    <a href="agent-profile.html" title="" class="ext-link">
                                        <img src="<?php echo e(asset('storage/'.$us->photo)); ?>" alt="" style="width:40%;">
                                    </a>
                                </div><!--member-img end-->
                                <div class="team-info">
                                    <h3><a href="agent-profile.html" title=""><?php echo e($us->name); ?></a></h3>
                                    <span><?php echo e($us->phone); ?></span>
                                    <p><?php echo e($us->email); ?></p>
                                    <a href="<?php echo e(route('afficherProfil',$us->id)); ?>" title="" class="lnk-default">View Profile</a>
                                </div><!--team-info end-->
                            </div><!--team end-->
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div><!--team-sec-details end-->
            </div>
        </section><!--recent-posts-sec end-->

        
       
</div>
<?php $__env->stopSection(); ?>

        <?php $__env->startSection('footer'); ?>
            <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>




<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>