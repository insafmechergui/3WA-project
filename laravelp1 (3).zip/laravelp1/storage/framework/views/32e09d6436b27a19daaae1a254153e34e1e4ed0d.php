<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('inc.head',['title'=>'Annonce categorie'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
            <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper">
<section class="page-content sec-padding">
            <div class="container">
                <div class="page-content-details">
                    <div class="row">
                        <div class="col-xl-8 col-lg-12">
                            <div class="listing-sec">
                                <div class="listing-control-head">
                                    <form>
                                        <div class="form-field">
                                            <div class="custom-select">
                                                <select>
                                                    <option value="0">Default Order</option>
                                                    <option value="1">By publish date ASC</option>
                                                    <option value="2">By publish date DESC</option>
                                                    <option value="3">By price ASC</option>
                                                    <option value="4">By price DESC</option>
                                                </select>
                                            </div>
                                        </div><!--form-field end-->
                                    </form>
                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link" id="vertical-tab" data-toggle="tab" href="#vertical-post" role="tab" aria-controls="vertical-post" aria-selected="true"><i class="fa fa-th"></i></a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link active" id="horizental-tab" data-toggle="tab" href="#horizental-post" role="tab" aria-controls="horizental-post" aria-selected="true"><i class="fa fa-list-ul"></i></a>
                                        </li>
                                    </ul>
                                </div><!--listing-control-head end-->
                                <div class="listing-items">
                                    <div class="tab-content">
                                        <div class="tab-pane" id="vertical-post" role="tabpanel" aria-labelledby="vertical-tab">
                                            <div class="sales-items">
                                                <div class="row">
                                                   <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <div class="col-xl-6 col-lg-6 col-md-6">

                                                        <div class="sale-item">
                                                            <div class="item-img">
                                                                <a href="11_Single_Properties_Standart.html" title="" class="ext-link">
                                                                    <?php if(count($cat->medias)>0): ?>
                                                                    <img src="<?php echo e(asset('storage/'.$cat->medias->first()->url)); ?>" alt="">
                                                                    <?php endif; ?>
                                                                </a>
                                                                <span class="item-status"><?php echo e($cat->type); ?></span>
                                                                <a href="11_Single_Properties_Standart.html" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <div class="item-info">
                                                                <h3><a href="" title=""><?php echo e($cat->titre); ?></a></h3>
                                                                <span><?php echo e($cat->etat); ?></span>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Baths: 2 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price"><?php echo e($cat->prix); ?> DT</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div><!--sale-item end-->

                                                    </div>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   
                                                </div>
                                            </div><!--sales-items end-->
                                        </div>
                                        <div class="tab-pane fade show active" id="horizental-post" role="tabpanel" aria-labelledby="horizental-tab">
                                            <div class="sales-items horizental-view">
                                                <div class="sale-item">
                                                    <div class="row">
                                                        <div class="col-lg-4 col-md-4 col-sm-4">
                                                            <div class="item-img">
                                                                <a href="11_Single_Properties_Standart.html" title="" class="ext-link">
                                                                    <img src="assets/images/resources/img4.jpg" alt="">
                                                                </a>
                                                                <span class="item-status">For Sale</span>
                                                                <a href="11_Single_Properties_Standart.html" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div><!--item-img end-->
                                                        </div>
                                                        <div class="col-lg-8 col-md-8 col-sm-8">
                                                            <div class="item-info">
                                                                <h3><a href="11_Single_Properties_Standart.html" title="">Dramatic and Unique Condo</a></h3>
                                                                <span>Reno Pl, San Francisco, CA 94133</span>
                                                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisielit quat ipsum, nec sagittis sem nibh id elit. Morbi accumsan sum velit. </p>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Baths: 2 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price">$499,500</strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->
                                                        </div>
                                                    </div>
                                                </div><!--sale-item end-->
                                               
                                            </div><!--sales-items end-->
                                        </div>
                                    </div>
                                </div><!--listing-items end-->
                                <div class="mai-pagination ta-left">
                                    <nav aria-label="Page navigation example">
                                        <ul class="pagination justify-content-center">
                                            <li class="page-item disabled">
                                              <a class="page-link" href="#" tabindex="-1"><i class="fa fa-angle-left"></i></a>
                                            </li>
                                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                                            <li class="page-item">
                                              <a class="page-link" href="#"><i class="fa fa-angle-right"></i></a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div><!--PAGINATION END-->
                            </div><!--listing-sec end-->
                        </div>
                        <div class="col-xl-4 col-lg-12 pl-35">
                            <div class="sidebar">
                                <div class="widget widget-search-properties">
                                    <h3 class="widget-title">Search Properties</h3>
                                    <form>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="form-field">
                                                    <label>All Location</label>
                                                    <div class="custom-select">
                                                        <select>
                                                            <option value="0">All Location</option>
                                                            <option value="1">California</option>
                                                            <option value="2">New York</option>
                                                            <option value="3">Chicago</option>
                                                            <option value="4">Las Vegas</option>
                                                            <option value="5">Fullerton</option>
                                                        </select>
                                                    </div>
                                                </div><!--form-field end-->
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="form-field">
                                                    <label>Property Type</label>
                                                    <div class="custom-select">
                                                        <select>
                                                            <option value="0">All Property Types</option>
                                                            <option value="1">Property type 1</option>
                                                            <option value="2">Property type 2</option>
                                                            <option value="3">Property type 3</option>
                                                            <option value="4">Property type 4</option>
                                                        </select>
                                                    </div>
                                                </div><!--form-field end-->
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="form-field">
                                                    <label>Status</label>
                                                    <div class="custom-select">
                                                        <select>
                                                            <option value="0">All Statuses</option>
                                                            <option value="1">Status 1</option>
                                                            <option value="2">Status 2</option>
                                                            <option value="3">Status 3</option>
                                                            <option value="4">Status 4</option>
                                                        </select>
                                                    </div>
                                                </div><!--form-field end-->
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-field">
                                                    <label>Price from</label>
                                                    <div class="handle-counter" id="handleCounter">
                                                        <input type="text" value="50">
                                                        <ul>
                                                            <li><button class="counter-minus btn"><i class="fa fa-caret-up"></i></button></li>
                                                            <li><button class="counter-plus btn"><i class="fa fa-caret-down"></i></button></li>
                                                        </ul>
                                                    </div>
                                                </div><!--form-field end-->
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-field">
                                                    <label>Price to</label>
                                                    <div class="handle-counter" id="handleCounter2">
                                                        <input type="text" value="60">
                                                        <ul>
                                                            <li><button class="counter-minus btn"><i class="fa fa-caret-up"></i></button></li>
                                                            <li><button class="counter-plus btn"><i class="fa fa-caret-down"></i></button></li>
                                                        </ul>
                                                    </div>
                                                </div><!--form-field end-->
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-field">
                                                    <label>Baths</label>
                                                    <div class="custom-select">
                                                        <select>
                                                            <option value="0">Any</option>
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                        </select>
                                                    </div>
                                                </div><!--form-field end-->
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="form-field">
                                                    <label>Beds</label>
                                                    <div class="custom-select">
                                                        <select>
                                                            <option value="0">Any</option>
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                        </select>
                                                    </div>
                                                </div><!--form-field end-->
                                            </div>
                                            <div class="col-lg-12">
                                                <button type="submit" class="lnk-default">Filter</button>
                                            </div>
                                        </div>
                                    </form>
                                </div><!--widget-search-properties end-->
                                <div class="widget widget-featured-propt">
                                    <h3 class="widget-title">Featured Properties</h3> 
                                    <div class="sale-item">
                                        <div class="item-img">
                                            <a href="11_Single_Properties_Standart.html" title="" class="ext-link">
                                                <img src="assets/images/resources/ft-img1.jpg" alt="">
                                            </a>
                                        </div>
                                        <div class="item-info">
                                            <div class="specs-info">
                                                <ul>
                                                    <li>Beds: 4 </li>
                                                    <li>Sqft: 1,570</li>
                                                </ul>
                                                <strong class="item-price">$499,500</strong>
                                            </div><!--specs-info end-->
                                        </div><!--item-info end-->
                                    </div>
                                </div><!--widget-featured-propt end-->
                            </div><!--sidebar end-->
                        </div>
                    </div>
                </div><!--page-content-details end-->
            </div>
        </section><!--page-content end-->

        <section class="subscribe-sec">
            <div class="container">
                <div class="subscribe-sec-details">
                    <h3>Find your perfect home</h3>
                    <a href="#" title="" class="lnk-default">Search NOW</a>
                </div><!--subscribe-sec-details end-->
            </div>
        </section><!--subscribe-sec end-->
        

    </div>
        
<?php $__env->stopSection(); ?>

        <?php $__env->startSection('footer'); ?>
            <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>