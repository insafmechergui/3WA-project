<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('inc.head',['title'=>'produit'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
            <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <section class="page-content sec-padding pt-0">
            <div class="container">
                <div class="page-content-details">
                    <div class="sale-item single-details">
                        <div class="item-info">
                            <div class="half-left">
                                <h3>Dramatic and Unique Condo</h3>
                                <div class="specs-info">
                                    <ul>
                                        <li>Beds: 4 </li>
                                        <li>Baths: 2 </li>
                                        <li>Sqft: 1,570</li>
                                    </ul>
                                </div><!--specs-info end-->
                            </div>
                            <div class="half-right">
                                <strong class="item-price">$499,500</strong>
                                <span>Reno Pl, San Francisco, CA 94133</span>
                            </div>
                        </div>
                        <div class="banner-carousel arrow-display">
                            
                            <div class="item-img">
                                <img src="assets/images/single-img.jpg" alt="">
                            </div>
                        </div><!--banner-carousel end-->
                        <div class="item-more-details">
                            <div class="row">
                                <div class="col-xl-8">
                                    <div class="single-post">
                                        <div class="pro-info description-pro">
                                            <h3>Description</h3>
                                            <div class="hidden open">
                                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisielit psum dolor sit amet, consectetur adipiscing elit. Curabitur fringilla, augue et volutpat lobortis, massa pretium purus, scele risque dignissim lectus dolor ut odio. Fusce varius, mi eget rhoncus mollis, ante ipsum porta enim, ullamcorper magna libero nec ex. Proin in felis massa. In hac habitasse platea ut tempus erat. Aliquam aimi auris lacus, eleifend dignissim velit non, ullamcorper vehicula orci. Sed auctor orci sem, semper uctus lacus ultrices sed. </p>
                                                <p>Aliquam ut elit finibus, mattis purus consectetur, lacinia erat. Quisque tincid acinia eler ifend. Aliquam erat volutpat. Nullam porttitor vitae mi ut hendrerit. Proin laoreet egestas bibe andum. Nulla in sapien ac risus posuere hendrerit vitae ac purus. Mauris sagittis tincidunt risus non porttitor.</p>
                                            </div>
                                        </div><!--pro-info end-->
                                        <div class="pro-info features-pro">
                                            <h3>Features</h3>
                                            <ul class="hidden open">
                                                <li><span>Central Heating</span></li>
                                                <li><span>Fire Alarm</span></li>
                                                <li><span>Home Theater</span></li>
                                                <li><span>TV Cable</span></li>
                                                <li><span>Dual Sinks</span></li>
                                                <li><span>Fire Place</span></li>
                                                <li><span>Laundry Room</span></li>
                                                <li><span>Wi-Fi</span></li>
                                                <li><span>Electric Range</span></li>
                                                <li><span>Wine Cellar</span></li>
                                                <li><span>Marble Floors</span></li>
                                                <li><span>Gym</span></li>
                                            </ul>
                                        </div><!--features-pro end-->
                                        <div class="pro-info add-details">
                                            <h3>Additional Details</h3>
                                            <ul class="hidden open">
                                                <li>
                                                    <strong>Appliance:</strong>
                                                    <span>Air Conditioning, Dishwasher, Dryer,  Built-In Range </span>
                                                </li>
                                                <li>
                                                    <strong>Bathroom Description:</strong>
                                                    <span>Tile Walls, Shower Over Tub, Bathtub </span>
                                                </li>
                                                <li>
                                                    <strong>Bedroom Features:</strong>
                                                    <span>Second Floor Bedroom, Master Suite, Walk-In Closet </span>
                                                </li>
                                                <li>
                                                    <strong>Dining Area:</strong>
                                                    <span>Dining Combo </span>
                                                </li>
                                                <li>
                                                    <strong>Doors & Windows:</strong>
                                                    <span>Stained Glass Windows, Wooden Doors </span>
                                                </li>
                                                <li>
                                                    <strong>Exterior Construction:</strong>
                                                    <span>Stucco</span>
                                                </li>
                                                <li>
                                                    <strong>Fireplace Location:</strong>
                                                    <span>Main Living Room </span>
                                                </li>
                                                <li>
                                                    <strong>Floor:</strong>
                                                    <span>Wall-to-Wall Carpet, Ceramic Tile </span>
                                                </li>
                                            </ul>
                                        </div><!--add-details end-->
                                        <div class="pro-info virtual-tour">
                                            <h3>Virtual Tour</h3>
                                            <div class="tour-vid hidden open">
                                                <img src="assets/images/resources/vt-img.jpg" alt="">
                                                <a href="https://www.youtube.com/watch?v=dRTwDndlrpE" title="" class="vid-play html5lightbox"><i class="fa fa-play"></i></a>
                                            </div>
                                        </div><!--virtual-tour end-->
                                        <div class="pro-info review-pro">
                                            <h3>Review</h3>
                                            <div class="comments-list hidden open">
                                                <ul>
                                                    <li>
                                                        <div class="comment">
                                                            <div class="cm-img">
                                                                <img src="assets/images/resources/cm-img1.png" alt="">
                                                            </div><!--cm-img end-->
                                                            <div class="comment-text">
                                                                <h3>Angelika Gladkaya</h3>
                                                                <span>December 15, 2019</span>
                                                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisielit quat ipsum, nec sagittis sem nibh id elit. Duis sed odio sitet nibh vulputate cursus a sit amet mauris. </p>
                                                                <ul class="rating-star">
                                                                    <li><i class="la la-star"></i></li>
                                                                    <li><i class="la la-star"></i></li>
                                                                    <li><i class="la la-star"></i></li>
                                                                    <li><i class="la la-star"></i></li>
                                                                    <li><i class="la la-star"></i></li>
                                                                </ul><!--rating-star end-->
                                                            </div><!--comment-text end-->
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="comment">
                                                            <div class="cm-img">
                                                                <img src="assets/images/resources/cm-img1.png" alt="">
                                                            </div><!--cm-img end-->
                                                            <div class="comment-text">
                                                                <h3>Angelika Gladkaya</h3>
                                                                <span>December 15, 2019</span>
                                                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisielit quat ipsum, nec sagittis sem nibh id elit. Duis sed odio sitet nibh vulputate cursus a sit amet mauris. </p>
                                                            </div><!--comment-text end-->
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div><!--review-sec end-->
                                            <div class="post-comment hidden open">
                                                <h4>Write a Review</h4>
                                                <ul class="rating-star">
                                                    <li><i class="la la-star"></i></li>
                                                    <li><i class="la la-star"></i></li>
                                                    <li><i class="la la-star"></i></li>
                                                    <li><i class="la la-star"></i></li>
                                                    <li><i class="la la-star"></i></li>
                                                </ul>
                                                <span>Rate Rating</span>
                                                <form class="js-ajax-form">
                                                    <div class="form-group">
                                                        <div class="missing-message">
                                                            Populate Missing Fields
                                                        </div>
                                                        <div class="success-message">
                                                            <i class="fa fa-check text-primary"></i> Thank you!. Your message is successfully sent...
                                                        </div>
                                                        <div class="error-message">Populate Missing Fields</div>
                                                    </div><!--form-group end-->
                                                    <div class="form-fields">
                                                        <div class="row">
                                                            <div class="col-lg-6">
                                                                <div class="form-field">
                                                                    <input type="text" name="name" placeholder="Name" id="name">
                                                                </div><!--form-field end-->
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <div class="form-field">
                                                                    <input type="email" name="email" placeholder="Email" id="email">
                                                                </div><!--form-field end-->
                                                            </div>
                                                            <div class="col-lg-12">
                                                                <div class="form-field">
                                                                    <textarea name="comment" placeholder="Comment"></textarea>
                                                                </div><!--form-field end-->
                                                            </div>
                                                            <div class="col-lg-12">
                                                                <div class="form-submit">
                                                                    <button type="submit" class="lnk-default submit">Send</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!--form-fields end-->
                                                </form>
                                            </div><!--post-comment end-->
                                        </div><!--review-pro end-->
                                        <div class="pro-info map-dv">
                                            <h3>Location</h3>
                                            <div id="map-container" class="fullwidth-home-map hidden open">
                                                <div id="map" data-map-zoom="9"></div>
                                            </div>
                                        </div><!--map-dv end-->
                                    </div><!--single end-->        
                                </div>
                                <div class="col-xl-4">
                                    <div class="sidebar pl-35">
                                        <div class="widget widget-form">
                                            <div class="auth-info">
                                                <div class="auth-img">
                                                    <img src="assets/images/resources/aut-img.png" alt="">
                                                </div>
                                                <div class="auth_info">
                                                    <h3>Oliver Fauller</h3>
                                                    <span>Moison Director</span>
                                                    <ul>
                                                        <li>
                                                            <i class="la la-phone"></i>
                                                            <span>+1 212-758-8877</span>
                                                        </li>
                                                        <li>
                                                            <i class="la la-envelope"></i>
                                                            <a href="#" title="">email@email.com</a>
                                                        </li>
                                                    </ul>
                                                </div><!--auth-info end-->
                                            </div><!--auth-info end-->
                                            <form>
                                                <div class="form-field">
                                                    <input type="text" name="name" placeholder="Your Name">
                                                </div><!--form-field end-->
                                                <div class="form-field">
                                                    <input type="text" name="email" placeholder="Your Email">
                                                </div><!--form-field end-->
                                                <div class="form-field">
                                                    <textarea placeholder="Your Message"></textarea>
                                                </div><!--form-field end-->
                                                <div class="form-submit">
                                                    <button type="submit" class="lnk-default">Send Message</button>
                                                </div>
                                            </form>
                                        </div><!--widget-form end-->
                                        <div class="widget widget-featured-propt">
                                            <h3 class="widget-title">Featured Properties</h3> 
                                            <div class="sale-item">
                                                <div class="item-img">
                                                    <a href="11_Single_Properties_Standart.html" title="" class="ext-link">
                                                        <img src="assets/images/resources/ft-img1.jpg" alt="">
                                                    </a>
                                                </div>
                                                <div class="item-info">
                                                    <div class="specs-info">
                                                        <ul>
                                                            <li>Beds: 4 </li>
                                                            <li>Sqft: 1,570</li>
                                                        </ul>
                                                        <strong class="item-price">$499,500</strong>
                                                    </div><!--specs-info end-->
                                                </div><!--item-info end-->
                                            </div>
                                        </div><!--widget-featured-propt end-->
                                    </div><!--sidebar end-->
                                </div>
                            </div>
                        </div><!--item-more-details end-->
                    </div><!--sale-item end-->
                </div><!--page-content-details end-->
            </div>
        </section><!--page-content end-->

        <section class="subscribe-sec">
            <div class="container">
                <div class="subscribe-sec-details">
                    <h3>Find your perfect home</h3>
                    <a href="#" title="" class="lnk-default">Search NOW</a>
                </div><!--subscribe-sec-details end-->
            </div>
        </section><!--subscribe-sec end-->
<?php $__env->stopSection(); ?>

        <?php $__env->startSection('footer'); ?>
            <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>

        
    <?php $__env->startSection('script'); ?>
            <?php echo $__env->make('inc.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>