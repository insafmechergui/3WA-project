            <div class="top-bar">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-6">
                            <address class="contact-num">
                                <span><i class="fa fa-phone"></i> +1 212 505 1015</span>
                            </address>
                        </div>
                        
                        <div class="col-lg-6 col-md-6 col-sm-6 col-6" style="color: white;">
                        <?php if(session('error')): ?>
                            <?php echo e(session('error')); ?>


                        <?php endif; ?>
                        
                        <?php if(Auth::user()): ?>
                                <span class="login-form"><a href="<?php echo e(route('showProfil')); ?>"></a></span>

                                <strong>Salut <?php echo e(Auth::user()->name); ?></strong>
                            <div class="log-details">

                            <a href="<?php echo e(route('handleLogOut')); ?>">Déconnexion</a>
                            </div><!--log-details end-->

                        <?php else: ?>
                            Non Connecté                      
                            <div class="log-details">
                                <span class="login-form"><i class="la la-user"></i> <b>Login</b>/<b>Register</b></span>
                            </div><!--log-details end-->
                        <?php endif; ?>
                        </div>

                            </div><!--wrapper end-->                           

                    </div>
                </div>
            </div><!--top-bar end-->
            <div class="bottom-header">
                <div class="container">
                    <div class="navigation text-right">
                        <nav>
                            <ul>
                                <li><a href="<?php echo e(route('showHome')); ?>" title="">Home</a>
                                    <ul>
                                        <li class="active"><a href="" title="">Home Alternative</a></li>
                                    </ul>
                                </li>
                                <li><a href="<?php echo e(route('showListing')); ?>" title="">Properties</a>
                                    <ul>
                                        <li><a href="" title="">Properties Grid Standart</a></li>
                                        <li><a href="03_Properties_Grid_Map_Full_Width.html" title="">Properties Grid Full Width</a></li>
                                        <li><a href="05_Properties_Grid_Map_Full_Width_Alternative.html" title="">Properties Grid Alternative</a></li>
                                        <li><a href="06_Properties_Half_Grid_Map_View.html" title="">Properties Grid Half Map</a></li>
                                        <li><a href="07_Properties_List_Map_Standart.html" title="">Properties List Standart</a></li>
                                        <li><a href="08_Properties_Half_List_Map_View.html" title="">Properties List Half Map</a></li>
                                        <li><a href="11_Single_Properties_Standart.html" title="">Single Properties</a></li>
                                    </ul>
                                </li>
                                <li><a href="<?php echo e(route('showAgent')); ?>" title="">Agents</a></li>
                            </ul>
                        </nav>
                    </div><!--navigation end-->
                    <div class="logo text-center">
                        <a href="01_Home.html" title="">
                            <img src="assets/images/logo.png" alt="">
                        </a>
                    </div>
                    <div class="navigation float-right text-left">
                        <nav>
                            <ul>
                                <li><a href="#" title="">Pages</a>
                                    <div class="mega-menu">
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <ul>
                                                    <li><h3>Column Menu 1</h3></li>
                                                    <li><a href="04_Properties_Grid_Map_Standart_Alternative.html" title="">Properties Grid Standart</a></li>
                                                    <li><a href="03_Properties_Grid_Map_Full_Width.html" title="">Properties Grid Map Full Width</a></li>
                                                    <li><a href="05_Properties_Grid_Map_Full_Width_Alternative.html" title="">Properties Grid Alternative</a></li>
                                                    <li><a href="06_Properties_Half_Grid_Map_View.html" title="">Properties Grid Half Map</a></li>
                                                    <li><a href="07_Properties_List_Map_Standart.html" title="">Properties List Standart</a></li>
                                                    <li><a href="08_Properties_Half_List_Map_View.html" title="">Properties List Half Map</a></li>
                                                </ul>       
                                            </div>
                                            <div class="col-lg-4">
                                                <ul>
                                                    <li><h3>Column Menu 2</h3></li>
                                                    <li><a href="09_Properties_Grid_Map_Hover.html" title="">Properties Grid Map Hover</a></li>
                                                    <li><a href="10_Properties_Half_Map_Grid_View_Full_Screen.html" title="">Properties Half Full Screen</a></li>
                                                    <li><a href="28_Properties_Half_List_Geo_Version_With_Geo_Map.html" title="">Properties  Geo Version </a></li>
                                                    <li><a href="11_Single_Properties_Standart.html" title="">Single Properties Standart</a></li>
                                                    <li><a href="12_Single_Properties_Image_Full_Width.html" title="">Single Properties Full Width</a></li>
                                                    <li><a href="13_Single_Properties_Gallery_Images.html" title="">Single Properties Gallery</a></li>
                                                </ul>     
                                            </div>
                                            <div class="col-lg-4">
                                                <ul>
                                                    <li><h3>Column Menu 3</h3></li>
                                                    <li><a href="18_Blog_Gallery.html" title="">Blog Standart</a></li>
                                                    <li><a href="15_Blog_Full_Width_Alternative.html" title="">Blog Full Width Alternative</a></li>
                                                    <li><a href="14_Blog_Grid.html" title="">Blog Grid 3 Column</a></li>
                                                    <li><a href="18_Blog_Gallery.html" title="">Blog Open Gallery</a></li>
                                                    <li><a href="../contact.blade.php" title="">Contact</a></li>
                                                </ul>     
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li><a href="<?php echo e(route('handleContact')); ?>" title="">Contact</a></li>
                        <?php if(Auth::user()): ?>
                            <li><a href="<?php echo e(route('showHomeAnnonce')); ?>" title="">Ajouter une annonce</a></li>
                        <?php endif; ?>


                            </ul>
                        </nav>
                    </div>
                    <div class="menu-btn">
                        <a href="#" title="">
                            <span class="bar1"></span>
                            <span class="bar2"></span>
                            <span class="bar3"></span>
                        </a>
                    </div><!--menu-btn end-->
                </div>
            </div><!--bottom-header end-->
             <div class="responsive-mobile-menu">
            <ul>
                <li><a class="active" href="01_Home.html" title="">Home</a>
                    <ul>
                        <li class="active"><a href="29_Home_Alternative.html" title="">Home Alternative</a></li>
                    </ul>
                </li>
                <li><a href="#" title="">Properties</a>
                    <ul>
                        <li><a href="04_Properties_Grid_Map_Standart_Alternative.html" title="">Properties Grid Standart</a></li>
                        <li><a href="03_Properties_Grid_Map_Full_Width.html" title="">Properties Grid Full Width</a></li>
                        <li><a href="05_Properties_Grid_Map_Full_Width_Alternative.html" title="">Properties Grid Alternative</a></li>
                        <li><a href="06_Properties_Half_Grid_Map_View.html" title="">Properties Grid Half Map</a></li>
                        <li><a href="07_Properties_List_Map_Standart.html" title="">Properties List Standart</a></li>
                        <li><a href="08_Properties_Half_List_Map_View.html" title="">Properties List Half Map</a></li>
                        <li><a href="11_Single_Properties_Standart.html" title="">Single Properties</a></li>
                    </ul>
                </li>
                <li><a href="<?php echo e(route('showAgent')); ?>" title="">Agents</a></li>
                <li><a href="#" title="">Pages</a>
                    <ul>
                        <li><h3>Column Menu 1</h3></li>
                        <li><a href="04_Properties_Grid_Map_Standart_Alternative.html" title="">Properties Grid Standart</a></li>
                        <li><a href="03_Properties_Grid_Map_Full_Width.html" title="">Properties Grid Map Full Width</a></li>
                        <li><a href="05_Properties_Grid_Map_Full_Width_Alternative.html" title="">Properties Grid Alternative</a></li>
                        <li><a href="06_Properties_Half_Grid_Map_View.html" title="">Properties Grid Half Map</a></li>
                        <li><a href="07_Properties_List_Map_Standart.html" title="">Properties List Standart</a></li>
                        <li><a href="08_Properties_Half_List_Map_View.html" title="">Properties List Half Map</a></li>
                        <li><h3>Column Menu 2</h3></li>
                        <li><a href="09_Properties_Grid_Map_Hover.html" title="">Properties Grid Map Hover</a></li>
                        <li><a href="10_Properties_Half_Map_Grid_View_Full_Screen.html" title="">Properties Half Full Screen</a></li>
                        <li><a href="28_Properties_Half_List_Geo_Version_With_Geo_Map.html" title="">Properties  Geo Version </a></li>
                        <li><a href="11_Single_Properties_Standart.html" title="">Single Properties Standart</a></li>
                        <li><a href="12_Single_Properties_Image_Full_Width.html" title="">Single Properties Full Width</a></li>
                        <li><a href="13_Single_Properties_Gallery_Images.html" title="">Single Properties Gallery</a></li>
                        <li><h3>Column Menu 3</h3></li>
                        <li><a href="18_Blog_Gallery.html" title="">Blog Standart</a></li>
                        <li><a href="15_Blog_Full_Width_Alternative.html" title="">Blog Full Width Alternative</a></li>
                        <li><a href="14_Blog_Grid.html" title="">Blog Grid 3 Column</a></li>
                        <li><a href="18_Blog_Gallery.html" title="">Blog Open Gallery</a></li>
                    </ul>
                </li>
                <li><a href="<?php echo e(route('handleContact')); ?>" title="">Contact</a></li>
                <li><a href="#" title="">Buy Template</a></li>
                <?php if(Auth::user()): ?>
                            <li><a href="<?php echo e(route('showHomeAnnonce')); ?>" title="">Ajouter une annonce</a></li>
                        <?php endif; ?>
            </ul>
        </div><!--responsive-mobile-menu end-->
