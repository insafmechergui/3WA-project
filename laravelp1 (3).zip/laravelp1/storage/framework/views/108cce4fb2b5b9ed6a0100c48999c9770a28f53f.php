<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('inc.head',['title'=>'accueil'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
            <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="responsive-mobile-menu">
            <ul>
                <li><a href="01_Home.html" title="">Home</a>
                    <ul>
                        <li class="active"><a href="29_Home_Alternative.html" title="">Home Alternative</a></li>
                    </ul>
                </li>
                <li><a href="#" title="">Properties</a>
                    <ul>
                        <li><a href="04_Properties_Grid_Map_Standart_Alternative.html" title="">Properties Grid Standart</a></li>
                        <li><a href="03_Properties_Grid_Map_Full_Width.html" title="">Properties Grid Full Width</a></li>
                        <li><a href="05_Properties_Grid_Map_Full_Width_Alternative.html" title="">Properties Grid Alternative</a></li>
                        <li><a href="06_Properties_Half_Grid_Map_View.html" title="">Properties Grid Half Map</a></li>
                        <li><a href="07_Properties_List_Map_Standart.html" title="">Properties List Standart</a></li>
                        <li><a href="08_Properties_Half_List_Map_View.html" title="">Properties List Half Map</a></li>
                        <li><a href="11_Single_Properties_Standart.html" title="">Single Properties</a></li>
                    </ul>
                </li>
                <li><a href="agents.html" title="">Agents</a></li>
                <li><a href="#" title="">Pages</a>
                    <ul>
                        <li><h3>Column Menu 1</h3></li>
                        <li><a href="04_Properties_Grid_Map_Standart_Alternative.html" title="">Properties Grid Standart</a></li>
                        <li><a href="03_Properties_Grid_Map_Full_Width.html" title="">Properties Grid Map Full Width</a></li>
                        <li><a href="05_Properties_Grid_Map_Full_Width_Alternative.html" title="">Properties Grid Alternative</a></li>
                        <li><a href="06_Properties_Half_Grid_Map_View.html" title="">Properties Grid Half Map</a></li>
                        <li><a href="07_Properties_List_Map_Standart.html" title="">Properties List Standart</a></li>
                        <li><a href="08_Properties_Half_List_Map_View.html" title="">Properties List Half Map</a></li>
                        <li><h3>Column Menu 2</h3></li>
                        <li><a href="09_Properties_Grid_Map_Hover.html" title="">Properties Grid Map Hover</a></li>
                        <li><a href="10_Properties_Half_Map_Grid_View_Full_Screen.html" title="">Properties Half Full Screen</a></li>
                        <li><a href="28_Properties_Half_List_Geo_Version_With_Geo_Map.html" title="">Properties  Geo Version </a></li>
                        <li><a href="11_Single_Properties_Standart.html" title="">Single Properties Standart</a></li>
                        <li><a href="12_Single_Properties_Image_Full_Width.html" title="">Single Properties Full Width</a></li>
                        <li><a href="13_Single_Properties_Gallery_Images.html" title="">Single Properties Gallery</a></li>
                        <li><h3>Column Menu 3</h3></li>
                        <li><a href="18_Blog_Gallery.html" title="">Blog Standart</a></li>
                        <li><a href="15_Blog_Full_Width_Alternative.html" title="">Blog Full Width Alternative</a></li>
                        <li><a href="14_Blog_Grid.html" title="">Blog Grid 3 Column</a></li>
                        <li><a href="18_Blog_Gallery.html" title="">Blog Open Gallery</a></li>
                    </ul>
                </li>
                <li><a class="active" href="20_Contact.html" title="">Contact</a></li>
                <li><a href="#" title="">Buy Template</a></li>
            </ul>
        </div><!--responsive-mobile-menu end-->

        <section class="page-content sec-padding">
            <div class="container p-0">
                <div class="page-content-details">
                    <div class="sec-title text-center">
                        <h3>Contact Us</h3>
                    </div><!--sec-title end-->
                    <div class="contact-sec">
                        <div class="row">
                            <div class="col-lg-8">
                                <div class="contact-details">
                                    <h3>Get In Touch</h3>
                                    <p>Fusce varius, mi eget rhoncus mollis, ante ipsum porta enim, ullamcorper magna libero nec ex. Aliquam auris lacus, eleifend dignissim velit non, er vehicula orci. Sed auctor mper uctus lacus ultrices sed. Aliquam ut elit finibus, mattis purus consectetur, lacinia erat. Quisque tincid acinia eler. Aliquam erati volutpat. </p>
                                    <div class="contact-form">
                                        <h3>Send us a message</h3>
                                        <form class="js-ajax-form">
                                            <div class="form-group">
                                                <div class="missing-message">
                                                    Populate Missing Fields
                                                </div>
                                                <div class="success-message">
                                                    <i class="fa fa-check text-primary"></i> Thank you!. Your message is successfully sent...
                                                </div>
                                                <div class="error-message">Populate Missing Fields</div>
                                            </div><!--form-group end-->
                                            <div class="form-fields">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <div class="form-field">
                                                            <input type="text" name="name" placeholder="Name" id="name">
                                                        </div><!--form-field end-->
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="form-field">
                                                            <input type="email" name="email" placeholder="Email" id="email">
                                                        </div><!--form-field end-->
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="form-field">
                                                            <textarea name="message" placeholder="Message"></textarea>
                                                        </div><!--form-field end-->
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="form-submit">
                                                            <button type="submit" class="lnk-default submit">Send</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div><!--form-fields end-->
                                        </form>
                                    </div><!--contact-form end-->
                                </div><!--contact-details end-->
                            </div>
                            <div class="col-lg-4">
                                <div id="map-container" class="fullwidth-home-map add-map">
                                    <div id="map" data-map-zoom="9"></div>
                                </div><!--MAP END-->
                            </div>
                        </div>
                    </div><!--contact-sec end-->
                </div><!--page-content-details end-->
            </div>
        </section><!--page-content end-->

        <section class="subscribe-sec">
            <div class="container">
                <div class="subscribe-sec-details">
                    <h3>Find your perfect home</h3>
                    <a href="#" title="" class="lnk-default">Search NOW</a>
                </div><!--subscribe-sec-details end-->
            </div>
        </section><!--subscribe-sec end-->
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('footer'); ?>
            <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>

        
    <?php $__env->startSection('script'); ?>
            <?php echo $__env->make('inc.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>