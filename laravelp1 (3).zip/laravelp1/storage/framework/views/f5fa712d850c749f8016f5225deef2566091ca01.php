        


<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('inc.head',['title'=>'User profil'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
            <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="wrapper">

        <section class="team-sec agent-page sec-padding pt-0">
            <div class="container">
                <div class="team-sec-details">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-6">
                            <div class="team">
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form method="post" action="<?php echo e(route('updateProfil')); ?>" enctype=“multipart/form-data”>
                                    <div class="form-field">
                                        <label for="nom">Nom: </label>
                                        <input type="text" name="nom" value="<?php echo e($us->name); ?>">
                                    </div><!--form-field end-->
                                    <div class="form-field">
                                        <label for="mail">email: </label>
                                        <input type="email" name="mail" value="<?php echo e($us->email); ?>">
                                    </div><!--form-field end-->
                                    <div class="form-field">
                                        <label for="password">Mot de passe: </label>
                                        <input type="password" name="password" value="<?php echo e($us->password); ?>">
                                    </div><!--form-field end-->
                                    <div class="form-field">
                                        <label for="nom">Photo de profile: </label>
                                        <input type="file" name="photo" value="<?php echo e($us->photo); ?>">
                                    </div><!--form-field end-->

                                    <div class="form-submit">
                                        <button type="submit" class="lnk-default">Enregistrer</button>
                                        <button type="reset" class="lnk-default">Annuler</button>
                                    </div><!--form-submit end-->
                                    <?php echo e(csrf_field()); ?>


                                </form>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div><!--team end-->
                        </div>
                    </div>
                </div><!--team-sec-details end-->
            </div>
        </section><!--TEAM-SEC END-->

    </div>
<?php $__env->stopSection(); ?>

        <?php $__env->startSection('footer'); ?>
            <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>