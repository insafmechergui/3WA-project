<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('inc.head',['title'=>'Agent'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper">

    <section class="team-sec agent-page sec-padding pt-0">
        <div class="container">
           <div class="sec-title m-0">
                <h3>Agents</h3>
            </div><!--sec-title end-->
            <div class="team-sec-details">
                <div class="row">
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-4 col-sm-6">
                        <div class="team">
                            <div class="member-img">
                                    <img src="<?php echo e(asset('storage/'.$us->photo)); ?>" alt="" style="width:60%;">

                            </div><!--member-img end-->
                            <div class="team-info">
                                <h3><a href="" title=""><?php echo e($us->name); ?></a></h3>
                                <span><?php echo e($us->phone); ?></span>
                                <p><?php echo e($us->email); ?> </p>
                                <a href="<?php echo e(route('afficherProfil',$us->id)); ?>" title="" class="lnk-default">View Profile</a>
                            </div><!--team-info end-->
                        </div><!--team end-->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div><!--team-sec-details end-->
            <div class="sec-title m-0">
                <h3>Commentaires</h3>
            </div><!--sec-title end-->
                <div class="page-content-details">
                    <div class="sale-item single-details">
                        <div class="item-more-details">
                            <div class="row">
                                <div class="col-xl-12">
                                    <div class="single-post">
                                        <div class="pro-info review-pro">
                                            <div class="comments-list hidden open">
                                                <ul>
                                             <?php $__currentLoopData = $cont; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <li>
                                                        <div class="comment">
                                                           
                                                            <div class="comment-text">
                                                                <h3><?php echo e($con->name); ?></h3>
                                                                 <span><?php echo e($con->created_at); ?></span>
                                                                 <p><?php echo e($con->email); ?></p>
                                                                <p><?php echo e($con->content); ?></p>
                                                                
                                                            </div><!--comment-text end-->
                                                        </div>
                                                    </li>
                                                    
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div><!--review-sec end-->
                                        </div><!--review-pro end-->
                                    </div><!--single end-->        
                                </div>
                            </div>
                        </div><!--item-more-details end-->
                    </div><!--sale-item end-->
                </div><!--page-content-details end-->
            </div>
        </section><!--page-content end-->


</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>