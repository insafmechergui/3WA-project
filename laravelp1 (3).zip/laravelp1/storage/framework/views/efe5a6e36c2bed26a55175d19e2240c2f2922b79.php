<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('inc.head',['title'=>'les Annonces'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
            <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 
    <div class="wrapper">
<h3>Résultat pour votre recherche de " <?php echo e($query); ?> "</h3>

        <section class="page-content half-map sec-padding pt-0">
            <div class="container-full">
                <div class="page-content-details">
                    <div class="row">
                        <div class="col-xl-6 pl-0 pr-0 half-wd order--1">
                                <div class="listing-items">
                                    <div class="tab-content">
                                        <div class="tab-pane fade show active" id="vertical-post" role="tabpanel" aria-labelledby="vertical-tab">
                                            <div class="sales-items">
                                                <div class="row">
                                                
                                             <?php if(isset($details)): ?>
                                                 
                                                  <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                                        <div class="sale-item">
                                                            <div class="item-img">
                                                                <?php if(count($rech->medias)>0): ?>
                                                                    <img src="<?php echo e(asset('storage/'.$rech->medias->first()->url)); ?>" alt="titre">
                                                                <?php endif; ?>
                                                                <span class="item-status"><?php echo e($rech->type); ?></span>
                                                                <a href="<?php echo e(route('showSingle',$rech->id)); ?>" title="" class="view-btn">View</a>
                                                                <div class="figcaption">
                                                                    <ul>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                        <li><i class="fa fa-star"></i></li>
                                                                    </ul>
                                                                    <a href="#" title="" class="add-to-cart"><i class="fa fa-heart"></i></a>
                                                                </div>
                                                            </div>

                                                            <div class="item-info">
                                                                <h3><?php echo e($rech->titre); ?></h3>
                                                                <span><?php echo e($rech->description); ?></span>
                                                                <div class="specs-info">
                                                                    <ul>
                                                                        <li>Beds: 4 </li>
                                                                        <li>Baths: 2 </li>
                                                                        <li>Sqft: 1,570</li>
                                                                    </ul>
                                                                    <strong class="item-price"><?php echo e($rech->prix); ?></strong>
                                                                </div><!--specs-info end-->
                                                            </div><!--item-info end-->

                                                        </div><!--sale-item end-->
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php elseif(isset($message)): ?>
                                            <span><?php echo e($message); ?></span>
                                           <?php endif; ?>
                                                   
                                                </div>
                                            </div><!--sales-items end-->
                                        </div>
                                    </div>
                                </div><!--listing-items end-->
                            </div><!--listing-sec end-->
                        </div>
                    </div>
                </div><!--page-content-details end-->
        </section><!--page-content end-->

</div>

<?php $__env->stopSection(); ?>

        <?php $__env->startSection('footer'); ?>
            <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>