<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('inc.head',['title'=>'User profil'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrapper">

    <section class="page-content sec-padding pb-50">
        <div class="container">
            <div class="sec-title m-0">
                <h3>Agents</h3>
            </div><!--sec-title end-->
        </div>
    </section><!--page-content end-->

    <section class="team-sec agent-page sec-padding pt-0">
        <div class="container">
            <div class="team-sec-details">
                <div class="row">
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-4 col-sm-6">
                        <div class="team">
                            <div class="member-img">
                                <a href="agent-profile.html" title="" class="ext-link">
                                    <img src="assets/images/resources/team1.jpg" alt="">
                                </a>
                            </div><!--member-img end-->
                            <div class="team-info">
                                <h3><a href="agent-profile.html" title=""><?php echo e($us->name); ?></a></h3>
                                <span>Moison Director</span>
                                <p><?php echo e($us->email); ?> </p>
                                <a href="<?php echo e(route('showProfil')); ?>" title="" class="lnk-default">View Profile</a>
                            </div><!--team-info end-->
                        </div><!--team end-->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div><!--team-sec-details end-->
        </div>
    </section><!--TEAM-SEC END-->

    <section class="testimonial-sec sec-padding">
        <div class="container">
            <div class="testimonial-carousel">
                <div class="testi-comment">
                    <ul class="rating-star">
                        <li><i class="la la-star"></i></li>
                        <li><i class="la la-star"></i></li>
                        <li><i class="la la-star"></i></li>
                        <li><i class="la la-star"></i></li>
                        <li><i class="la la-star"></i></li>
                    </ul>
                    <p>Aenean sollicitudin, lorem quis bibendum auctor, nisielit quat ipsum, nec sagittis sem nibh id elit. Duis sed odio sitet nibh vulputate cursus a sit amet mauris. </p>
                    <div class="testi-user-info">
                        <img src="assets/images/resources/user1.png" alt="">
                        <h3>Angelika Gladkaya</h3>
                    </div>
                </div><!--testi-comment end-->
                <div class="testi-comment">
                    <ul class="rating-star">
                        <li><i class="la la-star"></i></li>
                        <li><i class="la la-star"></i></li>
                        <li><i class="la la-star"></i></li>
                        <li><i class="la la-star"></i></li>
                        <li><i class="la la-star"></i></li>
                    </ul>
                    <p>Aenean sollicitudin, lorem quis bibendum auctor, nisielit quat ipsum, nec sagittis sem nibh id elit. Duis sed odio sitet nibh vulputate cursus a sit amet mauris. </p>
                    <div class="testi-user-info">
                        <img src="assets/images/resources/user1.png" alt="">
                        <h3>Angelika Gladkaya</h3>
                    </div>
                </div><!--testi-comment end-->
                <div class="testi-comment">
                    <ul class="rating-star">
                        <li><i class="la la-star"></i></li>
                        <li><i class="la la-star"></i></li>
                        <li><i class="la la-star"></i></li>
                        <li><i class="la la-star"></i></li>
                        <li><i class="la la-star"></i></li>
                    </ul>
                    <p>Aenean sollicitudin, lorem quis bibendum auctor, nisielit quat ipsum, nec sagittis sem nibh id elit. Duis sed odio sitet nibh vulputate cursus a sit amet mauris. </p>
                    <div class="testi-user-info">
                        <img src="assets/images/resources/user1.png" alt="">
                        <h3>Angelika Gladkaya</h3>
                    </div>
                </div><!--testi-comment end-->
            </div><!--testimonial-carousel end-->
        </div>
    </section><!--TESTIMONIAL-SEC END-->

    <section class="features-sec sec-padding">
        <div class="container">
            <div class="sec-title">
                <h3>Features</h3>
            </div><!--sec-title end-->
            <div class="features-sec-details">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                        <div class="feature_info">
                            <div class="feat-img">
                                <img src="assets/images/icon1.png" alt="">
                            </div>
                            <h3>Perfect Locations</h3>
                            <p>Aenean sollicitudin, lorem quis bibendum auctorlit psuma dolor sitoret amet, consectetur adipiscing elit. Curabitur fringilla, augue et volutpat lobortis,</p>
                        </div><!--feature_info end-->
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                        <div class="feature_info">
                            <div class="feat-img">
                                <img src="assets/images/icon2.png" alt="">
                            </div>
                            <h3>Top Specialist</h3>
                            <p>Aenean sollicitudin, lorem quis bibendum auctorlit psuma dolor sitoret amet, consectetur adipiscing elit. Curabitur fringilla, augue et volutpat lobortis,</p>
                        </div><!--feature_info end-->
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                        <div class="feature_info">
                            <div class="feat-img">
                                <img src="assets/images/icon3.png" alt="">
                            </div>
                            <h3>Exlusive Support</h3>
                            <p>Aenean sollicitudin, lorem quis bibendum auctorlit psuma dolor sitoret amet, consectetur adipiscing elit. Curabitur fringilla, augue et volutpat lobortis,</p>
                        </div><!--feature_info end-->
                    </div>
                </div>
            </div><!--features-sec-details end-->
        </div>
    </section><!--FEATURES-SEC END-->

    <section class="subscribe-sec">
        <div class="container">
            <div class="subscribe-sec-details">
                <h3>Find your perfect home</h3>
                <a href="#" title="" class="lnk-default">Search NOW</a>
            </div><!--subscribe-sec-details end-->
        </div>
    </section><!--subscribe-sec end-->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>